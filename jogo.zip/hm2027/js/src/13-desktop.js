
// =====================================================================================================
// Versão desktop (Tauri). Este módulo não faz nada no browser: só se activa quando existe window.__TAURI__
// (o Tauri injecta-o por causa de "withGlobalTauri": true em src-tauri/tauri.conf.json).
//  - As gravações vivem numa pasta própria (Documentos/Hoquei Manager 2027/Saves) e são escolhidas
//    DENTRO do jogo (lista de gravações), sem janelas do sistema.
//  - Qualquer outro "descarregar ficheiro" do jogo (diagnóstico, resumo da carreira) vai para
//    Documentos/Hoquei Manager 2027/Exportados, com um aviso no próprio jogo.
//  - (F11 e ecrã inteiro: ver 14-ecra.js.)
//  - Ligações externas abrem no browser do sistema.
// =====================================================================================================
(function(){
  const T = window.__TAURI__;
  const ativo = !!(T && T.fs && T.path);
  const D = { ativo: () => ativo };
  window.hm2027Desktop = D;
  if(!T) return;

  const PASTA = "Hoquei Manager 2027";
  const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  let _pastas = null;

  // Cria (se faltar) e devolve as pastas do jogo.
  async function pastas(){
    if(_pastas) return _pastas;
    let doc;
    try{ doc = await T.path.documentDir(); }                       // Windows/macOS: Documentos
    catch(_){ doc = await T.path.join(await T.path.homeDir(), "Documents"); }   // Linux sem pastas XDG
    const base = await T.path.join(doc, PASTA);
    const saves = await T.path.join(base, "Saves");
    const exportados = await T.path.join(base, "Exportados");
    await T.fs.mkdir(saves, { recursive: true });
    await T.fs.mkdir(exportados, { recursive: true });
    _pastas = { base, saves, exportados };
    return _pastas;
  }
  D.pastas = pastas;
  if(ativo) pastas().catch(() => {});   // a pasta existe logo desde o primeiro arranque

  // Nome de ficheiro seguro (Windows/macOS/Linux).
  function limparNome(n){
    let s = String(n || "").replace(/[\\\/:*?"<>|\u0000-\u001f]/g, " ").replace(/\s+/g, " ").trim();
    s = s.replace(/\.json$/i, "").replace(/[. ]+$/, "").slice(0, 80).trim();
    return s || "Jogo";
  }
  D.limparNome = limparNome;

  async function caminho(pasta, nomeFicheiro){ return T.path.join(pasta, nomeFicheiro); }

  // ---- Gravações -------------------------------------------------------------------------------
  // Lista [{nome, tamanho, data, meta}] por ordem da mais recente para a mais antiga.
  // Reconhece "x.json" e também "x.json.txt" / "x.txt" (o Windows/macOS escondem extensões e é fácil gravar
  // assim sem querer). Os ficheiros que não são reconhecidos ficam em D.ignorados (para o seletor os mostrar).
  const EXT_SAVE = /\.(json|txt)$/i;
  let _ficheiros = {};
  D.ignorados = [];
  function nomeBase(f){ return f.replace(/\.txt$/i, "").replace(/\.json$/i, ""); }
  D.listarSaves = async function(){
    const p = await pastas();
    const entradas = await T.fs.readDir(p.saves);
    const out = [];
    _ficheiros = {}; D.ignorados = [];
    for(const e of entradas){
      if(e.isDirectory || /^\./.test(e.name) || /\.hmmeta$/i.test(e.name)) continue;
      if(!EXT_SAVE.test(e.name)){ D.ignorados.push(e.name); continue; }
      const nome = nomeBase(e.name);
      if(_ficheiros[nome] && /\.json$/i.test(_ficheiros[nome])) continue;   // x.json tem prioridade sobre x.json.txt
      _ficheiros[nome] = e.name;
      let tamanho = 0, data = 0, meta = null;
      try{
        const st = await T.fs.stat(await caminho(p.saves, e.name));
        tamanho = st.size || 0; data = st.mtime ? new Date(st.mtime).getTime() : 0;
      }catch(_){}
      try{ meta = JSON.parse(await T.fs.readTextFile(await caminho(p.saves, nome + ".hmmeta"))); }catch(_){}
      const i = out.findIndex(o => o.nome === nome);
      const reg = { nome, tamanho, data, meta };
      if(i >= 0) out[i] = reg; else out.push(reg);
    }
    out.sort((a, b) => b.data - a.data);
    return out;
  };
  D.guardarSave = async function(nome, texto, meta){
    const p = await pastas();
    const n = limparNome(nome);
    await T.fs.writeTextFile(await caminho(p.saves, n + ".json"), texto);
    try{ await T.fs.writeTextFile(await caminho(p.saves, n + ".hmmeta"), JSON.stringify(meta || {})); }catch(_){}
    return n;
  };
  D.lerSave = async function(nome){
    const p = await pastas();
    return T.fs.readTextFile(await caminho(p.saves, _ficheiros[nome] || (nome + ".json")));
  };
  D.apagarSave = async function(nome){
    const p = await pastas();
    await T.fs.remove(await caminho(p.saves, _ficheiros[nome] || (nome + ".json")));
    try{ await T.fs.remove(await caminho(p.saves, nome + ".hmmeta")); }catch(_){}
  };
  D.abrirPasta = async function(){
    const p = await pastas();
    if(T.opener && T.opener.openPath) await T.opener.openPath(p.saves);
  };

  // ---- Exportações (diagnóstico, resumo final, ...) -------------------------------------------
  D.guardarTexto = async function(nomeSugerido, texto){
    const p = await pastas();
    const m = /^(.*?)(\.[A-Za-z0-9]+)?$/.exec(String(nomeSugerido));
    const base = limparNome(m[1] || "ficheiro"), ext = m[2] || ".txt";
    let nome = base + ext, i = 2;
    while(await T.fs.exists(await caminho(p.exportados, nome))) nome = `${base} (${i++})${ext}`;
    await T.fs.writeTextFile(await caminho(p.exportados, nome), texto);
    return await caminho(p.exportados, nome);
  };

  // ---- Aviso curto dentro do jogo (substitui os alert() do sistema) ---------------------------
  let _toastT = null;
  D.aviso = function(texto){
    let el = document.getElementById("hmToast");
    if(!el){ el = document.createElement("div"); el.id = "hmToast"; el.className = "hm-toast"; document.body.appendChild(el); }
    el.textContent = texto; el.classList.add("on");
    clearTimeout(_toastT); _toastT = setTimeout(() => el.classList.remove("on"), 4200);
  };

  // Qualquer <a download href="blob:..."> clicado por código (diagnóstico, resumo final, etc.).
  if(ativo){
    const clickOriginal = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function(){
      const href = this.href || "", nome = this.download;
      if(nome && href.indexOf("blob:") === 0){
        fetch(href).then(r => r.text()).then(txt => D.guardarTexto(nome, txt))
          .then(c => D.aviso("Ficheiro guardado em: " + c))
          .catch(e => D.aviso("Não foi possível guardar o ficheiro: " + (e && e.message ? e.message : e)));
        return;
      }
      return clickOriginal.apply(this, arguments);
    };
  }

  // ---- Seletor de gravações dentro do jogo -----------------------------------------------------
  let ui = null, modo = null, ctx = null, lista = [], sel = null, pendente = null, ocupado = false;

  function construirUi(){
    if(ui) return ui;
    const ov = document.createElement("div");
    ov.className = "overlay hidden"; ov.id = "savesOverlay"; ov.style.zIndex = "10050"; // acima do ecrã de falência (10000), para se poder carregar depois de uma falência
    ov.innerHTML = `
      <div class="select-card saves-card">
        <h2 id="savesTitulo"></h2>
        <p class="helptext" id="savesPasta"></p>
        <div class="saves-guardar" id="savesGuardarRow">
          <label for="savesNome" class="set-lbl">Nome da gravação</label>
          <input id="savesNome" class="saves-input" maxlength="80" autocomplete="off" spellcheck="false">
        </div>
        <div class="saves-lista" id="savesLista"></div>
        <div class="saves-msg" id="savesMsg"></div>
        <div class="modal-actions saves-acoes">
          <button class="btn btn-ghost" id="savesAbrirPasta" title="Abre a pasta das gravações no computador">📁 Abrir pasta</button>
          <span class="saves-esp"></span>
          <button class="btn btn-ghost" id="savesApagarBtn">🗑 Apagar</button>
          <button class="btn btn-primary" id="savesOkBtn"></button>
          <button class="btn btn-ghost" id="savesFecharBtn">Fechar</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    const q = id => ov.querySelector("#" + id);
    ui = { ov, titulo: q("savesTitulo"), pasta: q("savesPasta"), nomeRow: q("savesGuardarRow"), nome: q("savesNome"),
           lista: q("savesLista"), msg: q("savesMsg"), ok: q("savesOkBtn"), apagar: q("savesApagarBtn"),
           abrirPasta: q("savesAbrirPasta"), fechar: q("savesFecharBtn") };
    ui.fechar.addEventListener("click", fecharSeletor);
    ov.addEventListener("click", e => { if(e.target === ov) fecharSeletor(); });
    document.addEventListener("keydown", e => {
      if(e.key === "Escape" && !ov.classList.contains("hidden")){ e.stopPropagation(); fecharSeletor(); }
    }, true);
    ui.nome.addEventListener("input", () => { pendente = null; mensagem(""); atualizarBotoes(); });
    ui.nome.addEventListener("keydown", e => { if(e.key === "Enter") accaoPrincipal(); });
    ui.ok.addEventListener("click", accaoPrincipal);
    ui.apagar.addEventListener("click", accaoApagar);
    ui.abrirPasta.addEventListener("click", () => D.abrirPasta().catch(e => mensagem("Não foi possível abrir a pasta: " + (e && e.message ? e.message : e), "erro")));
    return ui;
  }
  function mensagem(texto, tipo){
    ui.msg.textContent = texto || ""; ui.msg.className = "saves-msg" + (tipo ? " " + tipo : "");
  }
  function fecharSeletor(){ if(ui) ui.ov.classList.add("hidden"); modo = null; ctx = null; }
  function fmtTam(b){ return b >= 1048576 ? (b / 1048576).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(b / 1024)) + " KB"; }
  function fmtData(ms){
    if(!ms) return "—";
    const d = new Date(ms), p = n => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }
  function atualizarBotoes(){
    const guardar = modo === "guardar";
    if(guardar){
      const existe = lista.some(s => s.nome.toLowerCase() === limparNome(ui.nome.value).toLowerCase());
      ui.ok.textContent = pendente === "sub" ? "Confirmar: substituir" : (existe ? "Substituir" : "💾 Guardar");
      ui.ok.disabled = ocupado || !ui.nome.value.trim();
    }else{
      ui.ok.textContent = pendente === "car" ? "Confirmar: carregar" : "📂 Carregar";
      ui.ok.disabled = ocupado || !sel;
    }
    ui.apagar.textContent = pendente === "apg" ? "Confirmar: apagar" : "🗑 Apagar";
    ui.apagar.disabled = ocupado || !sel;
  }
  function avisoIgnorados(){
    if(!D.ignorados || !D.ignorados.length) return "";
    const nomes = D.ignorados.slice(0, 6).map(esc).join(", ") + (D.ignorados.length > 6 ? "…" : "");
    return `<div style="margin-top:8px;color:var(--aviso,#e0b050)">Ficheiros nesta pasta que não foram reconhecidos (têm de acabar em .json): ${nomes}</div>`;
  }
  function desenharLista(){
    if(!lista.length){
      ui.lista.innerHTML = `<div class="saves-vazio">Ainda não há gravações.${modo === "carregar" ? " Dentro do jogo, usa 💾 Guardar para criar a primeira. Para usar gravações de outra pessoa, copia os ficheiros .json para a pasta indicada acima (o botão 📁 Abrir pasta leva-te lá)." : ""}${avisoIgnorados()}</div>`;
      return;
    }
    ui.lista.innerHTML = lista.map((s, i) => {
      const m = s.meta || {};
      const linha = [m.clube, m.epoca ? "Época " + m.epoca : "", m.data, m.treinador ? "Treinador: " + m.treinador : ""].filter(Boolean).join(" · ");
      return `<div class="saves-row${sel === s.nome ? " sel" : ""}" data-i="${i}" role="option" tabindex="0">
        <div class="saves-row-main"><div class="saves-row-nome">${esc(s.nome)}</div><div class="saves-row-meta">${esc(linha || "Gravação sem informação adicional")}</div></div>
        <div class="saves-row-lado"><div>${fmtData(s.data)}</div><div>${fmtTam(s.tamanho)}</div></div>
      </div>`;
    }).join("") + avisoIgnorados();
    ui.lista.querySelectorAll(".saves-row").forEach(el => {
      const escolher = () => {
        const s = lista[+el.dataset.i]; sel = s.nome; pendente = null; mensagem("");
        if(modo === "guardar") ui.nome.value = s.nome;
        desenharLista(); atualizarBotoes();
      };
      el.addEventListener("click", escolher);
      el.addEventListener("keydown", e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); escolher(); } });
      el.addEventListener("dblclick", () => { if(modo === "carregar"){ escolher(); accaoPrincipal(); } });
    });
  }
  async function recarregarLista(){
    try{ lista = await D.listarSaves(); }
    catch(e){ lista = []; mensagem("Não foi possível ler a pasta das gravações: " + (e && e.message ? e.message : e), "erro"); }
    if(sel && !lista.some(s => s.nome === sel)) sel = null;
    desenharLista(); atualizarBotoes();
  }
  async function abrirSeletor(m, c){
    construirUi();
    modo = m; ctx = c || {}; sel = null; pendente = null; ocupado = false; lista = [];
    ui.titulo.textContent = m === "guardar" ? "💾 Guardar jogo" : "📂 Carregar jogo";
    ui.nomeRow.style.display = m === "guardar" ? "" : "none";
    ui.nome.value = m === "guardar" ? limparNome(ctx.nome || "") : "";
    mensagem(""); ui.lista.innerHTML = '<div class="saves-vazio">A ler a pasta…</div>';
    ui.pasta.textContent = "";
    ui.ov.classList.remove("hidden");
    try{ const p = await pastas(); ui.pasta.textContent = "Pasta das gravações: " + p.saves; }
    catch(e){ ui.pasta.textContent = ""; mensagem("Não foi possível criar/aceder à pasta das gravações: " + (e && e.message ? e.message : e), "erro"); }
    atualizarBotoes();
    await recarregarLista();
    if(m === "guardar"){ ui.nome.focus(); ui.nome.select(); }
  }
  async function accaoPrincipal(){
    if(ocupado || !modo) return;
    if(modo === "guardar"){
      const nome = limparNome(ui.nome.value);
      if(!ui.nome.value.trim()) return;
      const existe = lista.some(s => s.nome.toLowerCase() === nome.toLowerCase());
      if(existe && pendente !== "sub"){
        pendente = "sub"; mensagem(`Já existe uma gravação chamada «${nome}». Carrega em "Confirmar: substituir" para a substituir.`, "aviso");
        atualizarBotoes(); return;
      }
      ocupado = true; atualizarBotoes();
      try{
        const c = ctx; const n = await D.guardarSave(nome, c.json, c.meta);
        fecharSeletor(); D.aviso(`Jogo guardado: ${n}`); if(c.aoGuardar) c.aoGuardar(n);
      }catch(e){ ocupado = false; mensagem("Não foi possível guardar: " + (e && e.message ? e.message : e), "erro"); atualizarBotoes(); }
    }else{
      if(!sel) return;
      if(ctx.haProgresso && pendente !== "car"){
        pendente = "car"; mensagem("Isto substitui o teu progresso atual pelo jogo escolhido. Carrega em \"Confirmar: carregar\" para continuar.", "aviso");
        atualizarBotoes(); return;
      }
      ocupado = true; atualizarBotoes();
      try{
        const nomeSel = sel; const texto = await D.lerSave(nomeSel); const c = ctx;
        fecharSeletor(); if(c.aoCarregar) c.aoCarregar(texto, nomeSel);
      }catch(e){ ocupado = false; mensagem("Não foi possível ler a gravação: " + (e && e.message ? e.message : e), "erro"); atualizarBotoes(); }
    }
  }
  async function accaoApagar(){
    if(ocupado || !sel) return;
    if(pendente !== "apg"){ pendente = "apg"; mensagem(`Apagar «${sel}»? Não dá para desfazer. Carrega em "Confirmar: apagar".`, "aviso"); atualizarBotoes(); return; }
    ocupado = true; atualizarBotoes();
    try{ const n = sel; await D.apagarSave(n); sel = null; pendente = null; ocupado = false; await recarregarLista(); mensagem(`«${n}» apagada.`, "ok"); return; }
    catch(e){ mensagem("Não foi possível apagar: " + (e && e.message ? e.message : e), "erro"); }
    pendente = null; ocupado = false; await recarregarLista();
  }
  D.abrirGuardar = c => abrirSeletor("guardar", c);
  D.abrirCarregar = c => abrirSeletor("carregar", c);

  // Ligações externas (ex.: Wikipédia) abrem no browser do sistema.
  document.addEventListener("click", (e) => {
    const a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
    if(!a) return;
    const href = a.getAttribute("href") || "";
    if(/^https?:\/\//i.test(href) && T.opener && T.opener.openUrl){
      e.preventDefault();
      T.opener.openUrl(href).catch(() => {});
    }
  });
})();
