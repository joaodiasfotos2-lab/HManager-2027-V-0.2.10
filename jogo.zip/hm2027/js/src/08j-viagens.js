// Viagens e congestionamento (2026-10-12, pedido do utilizador: ideia 8 da quinta lista).
// Decisões de desenho confirmadas por ele:
//  - efeitos: CUSTO FINANCEIRO + FADIGA/CONDIÇÃO da equipa que se desloca;
//  - a distância mede-se por ZONA GEOGRÁFICA (4 escalões, não por quilómetros);
//  - as deslocações europeias para OUTRO PAÍS custam mais e cansam mais.
//
// Escalões: 0 = mesma zona · 1 = outra zona do continente · 2 = ilhas (Açores/Madeira) ·
// 3 = estrangeiro (outro país). Quem viaja é sempre o visitante: paga a deslocação (categoria
// "Deslocação", ver processMatchFinances) e perde condição física antes do apito inicial
// (condição persistente do plantel — recupera depois com o descanso normal, ver
// dailyConditionRecovery). Não há viagem em jogos de preparação nem em recintos neutros.
//
// Dentro do escalão 1 a distância ainda escala um pouco consoante o número de zonas que separa
// as duas equipas (ex.: Norte→Centro custa menos do que Norte→Sul).

const VIAGEM_CUSTOS = [700, 1500, 7000, 14000];   // €; escalão 3 = valor europeu histórico
const VIAGEM_FADIGA = [0, 3, 6, 9];               // pontos de condição perdidos (média por jogador)
const VIAGEM_ESCALA_ZONA = 0.2;                    // +20% de custo/fadiga por cada zona extra de distância (escalão 1)
const VIAGEM_NOMES = ["mesma zona", "outra zona", "ilhas", "estrangeiro"];

// Zonas por país, na ordem geográfica (a distância em zonas é a diferença de posições).
const VIAGEM_ZONAS = {
  pt: ["norte", "centro", "lisboa", "sul"],
  es: ["galiza", "madrid", "levante", "catalunha"],
  it: ["nord", "centro", "sud"],
};
const VIAGEM_ZONA_ROTULO = {
  norte: "Norte", centro: "Centro", lisboa: "Lisboa e Vale do Tejo", sul: "Sul", acores: "Açores", madeira: "Madeira",
  galiza: "Galiza", madrid: "Madrid", levante: "Levante", catalunha: "Catalunha",
  nord: "Norte de Itália", sud: "Sul de Itália",
};
// Palavras-chave (sem acentos, minúsculas) da cidade do pavilhão. A primeira lista com correspondência
// ganha; o que não corresponde a nenhuma fica na zona por omissão do país (a última, listada abaixo).
const VIAGEM_CIDADES = {
  pt: [
    ["acores", ["ponta delgada", "candelaria", "acores"]],
    ["madeira", ["funchal", "camara de lobos", "machico", "santa cruz da madeira"]],
    ["sul", ["loule", "boliqueime", "grandola", "santiago do cacem", "faro", "algarve", "beja", "evora"]],
    ["lisboa", ["lisboa", "oeiras", "cascais", "estoril", "parede", "murches", "sintra", "massama", "alenquer",
      "torres vedras", "loures", "tojal", "vila franca de xira", "seixal", "amora", "setubal", "azeitao", "sesimbra", "paco de arcos"]],
    ["centro", ["aveiro", "cacia", "mealhada", "coimbra", "sao pedro do sul", "leiria", "colmeias", "marinha grande",
      "alcobaca", "turquel", "ourem", "tomar", "santa cita", "entroncamento"]],
  ],
  es: [
    ["galiza", ["a coruna", "coruna", "vigo", "santiago de compostela", "ordes", "oviedo"]],
    ["madrid", ["rivas", "madrid", "alcobendas", "getxo"]],
    ["levante", ["alcoy", "alcoi", "valencia"]],
  ],
  it: [
    ["centro", ["castiglione della pescaia", "follonica", "forte dei marmi", "sarzana", "torre del lago", "viareggio"]],
    ["sud", ["giovinazzo", "matera"]],
  ],
};
const VIAGEM_ZONA_OMISSAO = { pt: "norte", es: "catalunha", it: "nord" };

function viagemNormalizar(s){
  return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}
function viagemPais(team){
  if(team && team.pais) return team.pais;
  return typeof teamCountry === "function" ? teamCountry(team) : "pt";
}
// Zona geográfica do clube (pela cidade do pavilhão). Clubes de países sem mapa (clubes "nuvem"
// de França, Alemanha, Suíça, Inglaterra…) devolvem zona null: só se sabe o país.
function viagemZona(team){
  if(!team) return null;
  const pais = viagemPais(team);
  const listas = VIAGEM_CIDADES[pais];
  if(!listas) return null;
  const cidade = viagemNormalizar(team.cidadePavilhao);
  for(const [zona, chaves] of listas){
    if(chaves.some(k => cidade.includes(k))) return zona;
  }
  return VIAGEM_ZONA_OMISSAO[pais] || null;
}
function viagemEIlha(zona){ return zona === "acores" || zona === "madeira"; }

// Informação completa de uma deslocação (visitante → recinto da casa).
// opts: { internacional } (opcional — vem dos chamadores europeus; o país das equipas também decide).
function viagemInfo(home, away, opts){
  const paisC = viagemPais(home), paisF = viagemPais(away);
  const zonaC = viagemZona(home), zonaF = viagemZona(away);
  let tier, escala = 1;
  const internacional = paisC !== paisF || !!(opts && opts.internacional);
  if(internacional){
    tier = 3;
  } else if(viagemEIlha(zonaC) || viagemEIlha(zonaF)){
    tier = zonaC === zonaF ? 0 : 2;     // Funchal ↔ Câmara de Lobos é viagem curta; Açores ↔ Madeira conta como ilhas
  } else if(zonaC != null && zonaC === zonaF){
    tier = 0;
  } else {
    tier = 1;
    const ordem = VIAGEM_ZONAS[paisC];
    if(ordem && zonaC && zonaF){
      const d = Math.abs(ordem.indexOf(zonaC) - ordem.indexOf(zonaF));
      if(d >= 1) escala = 1 + VIAGEM_ESCALA_ZONA * (d - 1);
    }
  }
  const custoBase = tier === 3 && typeof EUROPA_CUSTO_DESLOCACAO_INTERNACIONAL === "number" ? EUROPA_CUSTO_DESLOCACAO_INTERNACIONAL : VIAGEM_CUSTOS[tier];
  return {
    tier, nome: VIAGEM_NOMES[tier], internacional,
    custo: Math.round(custoBase * escala),
    fadiga: Math.round(VIAGEM_FADIGA[tier] * escala * 10) / 10,
    zonaCasa: zonaC, zonaFora: zonaF,
  };
}
function viagemTexto(info){
  if(!info) return "";
  const z = z => VIAGEM_ZONA_ROTULO[z] || "";
  if(info.tier === 0) return "Deslocação curta (mesma zona)";
  if(info.tier === 3) return "Deslocação internacional (avião + hotel)";
  if(info.tier === 2) return "Deslocação às ilhas (avião + hotel)";
  return `Deslocação longa${info.zonaFora && info.zonaCasa ? ` (${z(info.zonaFora)} → ${z(info.zonaCasa)})` : ""}`;
}

// Aplica a fadiga da viagem a quem se desloca (convocados). Cada jogador sente-a de forma um
// pouco diferente (±25%); nunca baixa a condição abaixo de 0. Devolve a perda média aplicada.
function viagemAplicarFadiga(info, jogadores){
  if(!info || !(info.fadiga > 0)) return 0;
  const lista = (jogadores || []).filter(Boolean);
  let total = 0;
  lista.forEach(p => {
    const perda = info.fadiga * (0.75 + Math.random() * 0.5);
    const antes = p.condicao != null && Number.isFinite(p.condicao) ? p.condicao : 100;
    p.condicao = roundDecimal(clamp(antes - perda, 0, 100));
    total += antes - p.condicao;
  });
  return lista.length ? total / lista.length : 0;
}
// Regras comuns a jogo ao vivo e simulado: não há viagem em amigáveis, recintos neutros, nem
// quando falta a cidade do pavilhão (ex.: seleções nacionais).
function viagemAplicavel(home, away, neutralVenue){
  if(neutralVenue || state.pendingAmigavel) return false;
  return !!(home && away && home.cidadePavilhao && away.cidadePavilhao);
}
