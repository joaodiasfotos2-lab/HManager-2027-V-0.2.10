// Adeptos e sócios (2026-10-11, pedido do utilizador: ideia 3 da terceira lista de ideias).
// Decisões de desenho confirmadas por ele:
//  - o número de sócios é visível (é um facto do clube, como a assistência); o humor da massa
//    adepta NUNCA aparece como número, só como estado qualitativo (eufóricos, satisfeitos,
//    expectantes, impacientes, revoltados) mais a tendência e as razões;
//  - o humor sobe e desce com resultados e sequências, expectativas face ao objetivo da direção,
//    e vendas de ídolos / contratações sonantes;
//  - efeitos: assistência (bilheteira), quotas de sócios como receita mensal, e um pequeno fator
//    casa no motor (±2,5%);
//  - ações do utilizador: preço das quotas, campanha de sócios e reunir com a claque.
//
// Modelo (team.adeptos, criado de forma preguiçosa só para clubes principais, guardado nos saves
// porque as equipas já são clonadas por inteiro):
//   humor        0–100, oculto
//   refMes       humor no mês anterior (tendência)
//   socios       número de sócios (visível); tende, 20% por mês, para sociosAlvo
//   sociosRef    número de sócios "de referência" do clube: quotas calibradas / preço de referência
//   quotaMensal  preço mensal da quota (referência por divisão; ver ADEPTOS_QUOTA_REF)
//   campanha     campanha em curso { resolveEm, custo } ou null; campanhaBonus decai 12% por mês
//   idolosIds    os 3 jogadores mais queridos na última sincronização (detecta saídas)
//   plantelIds   ids do plantel na última sincronização (detecta chegadas)
//   eventos      últimas reações (para as razões mostradas)

const ADEPTOS_BASE_ALVO = 55;
const ADEPTOS_FATOR_CASA_MAX = 0.025; // ±2,5% em ataque e defesa, só em casa
// 2026-10-16: quotas reais destes clubes: ~1,5 € (clubes pequenos) a ~4 € (grandes) por mês.
const ADEPTOS_QUOTA_REF = { placard: 4, "ok-liga": 4, "serie-a1": 4, "2div": 2.5, "ok-liga-plata": 2.5, "3div": 1.5 };
const ADEPTOS_QUOTA_OPCOES = [
  { id: "muito-baixa", mult: 0.75, label: "Muito baixa" },
  { id: "baixa", mult: 0.88, label: "Baixa" },
  { id: "normal", mult: 1, label: "Normal" },
  { id: "alta", mult: 1.15, label: "Alta" },
  { id: "muito-alta", mult: 1.3, label: "Muito alta" },
];
const ADEPTOS_QUOTA_COOLDOWN_DIAS = 90;
const ADEPTOS_CAMPANHA_COOLDOWN_DIAS = 120;
const ADEPTOS_CLAQUE_COOLDOWN_DIAS = 45;
const ADEPTOS_NIVEIS = [
  { id: "euforicos", min: 78, label: "Adeptos eufóricos", cor: "#3FA34D", texto: "O pavilhão vive um momento de euforia: a massa adepta acredita e empurra a equipa." },
  { id: "satisfeitos", min: 62, label: "Adeptos satisfeitos", cor: "#86C440", texto: "Os adeptos estão contentes com o rumo do clube e apoiam a equipa." },
  { id: "expectantes", min: 46, label: "Adeptos expectantes", cor: "#F3C623", texto: "Sem euforia nem revolta: a massa adepta espera para ver o que a equipa vale." },
  { id: "impacientes", min: 30, label: "Adeptos impacientes", cor: "#E8892B", texto: "A paciência está a esgotar-se nas bancadas. Mais um tropeção e os assobios começam." },
  { id: "revoltados", min: 0, label: "Adeptos revoltados", cor: "#D6402F", texto: "A massa adepta está revoltada e isso já se ouve no pavilhão." },
];

function adeptosElegivel(team) {
  return typeof balnearioElegivel === "function" ? balnearioElegivel(team) : !!(team && Array.isArray(team.players) && team.players.length && !team.equipaPrincipalId);
}
function adeptosFmtQuota(v) {
  return `${Number(v).toLocaleString("pt-PT", { minimumFractionDigits: 0, maximumFractionDigits: 2 })} €`;
}
function adeptosNivel(humor) {
  return ADEPTOS_NIVEIS.find(n => humor >= n.min) || ADEPTOS_NIVEIS[ADEPTOS_NIVEIS.length - 1];
}
// Preço de referência da quota: entre 1,5 € (clubes pequenos) e 4 € (grandes),
// interpolado pela receita anual de quotas calibrada do clube (em dinheiro, sem circularidade).
const ADEPTOS_QUOTA_ESCALA = {
  placard: { min: 1.5, max: 4, lo: 70000, hi: 200000 },
  "ok-liga": { min: 1.5, max: 4, lo: 70000, hi: 200000 },
  "serie-a1": { min: 1.5, max: 4, lo: 70000, hi: 200000 },
  "2div": { min: 1.5, max: 2.5, lo: 20000, hi: 55000 },
  "ok-liga-plata": { min: 1.5, max: 2.5, lo: 20000, hi: 55000 }
};
function adeptosQuotaRef(team) {
  const esc = ADEPTOS_QUOTA_ESCALA[team.divisaoAtual];
  if (!esc) return ADEPTOS_QUOTA_REF[team.divisaoAtual] || ADEPTOS_QUOTA_REF["2div"];
  const inc = (calibratedRecurringIncomeParts(team).quotas || 0) * 12;
  const k = Math.max(0, Math.min(1, (inc - esc.lo) / (esc.hi - esc.lo)));
  return Math.round((esc.min + (esc.max - esc.min) * k) * 2) / 2;
}
function adeptosSociosRef(team) {
  const calib = calibratedRecurringIncomeParts(team).quotas || 0;
  return Math.max(20, Math.round(calib / adeptosQuotaRef(team)));
}
function adeptosPosicao(team) {
  const comp = typeof competitionOfTeam === "function" ? competitionOfTeam(team) : null;
  if (!comp) return null;
  const tb = standingsForCompetition(comp.id) || [];
  const idx = tb.findIndex(x => x.id === team.id);
  if (idx < 0) return null;
  return { pos: idx + 1, total: tb.length, jogos: (tb[idx].J != null ? tb[idx].J : (team.stats && team.stats.J) || 0) };
}

// Alvo estrutural do humor: expectativas face ao objetivo da direção e forma recente.
function adeptosFatores(team) {
  let expect = 0;
  const p = adeptosPosicao(team);
  if (p && p.jogos >= 3 && p.total > 1) {
    const alvoPos = directionObjectiveTargetPosition(team, p.total);
    expect = clamp((alvoPos - p.pos) / Math.max(2, p.total / 3), -1.5, 1.5);
  }
  const rec = (team.recentResults || []).slice(-6);
  let forma = 0;
  if (rec.length >= 3) {
    const pts = rec.reduce((s, r) => s + (r === "V" ? 3 : r === "E" ? 1 : 0), 0);
    forma = clamp(pts / rec.length - 1, -1, 1.5);
  }
  const alvo = clamp(ADEPTOS_BASE_ALVO + 14 * expect + 6 * forma, 10, 92);
  return { expect, forma, alvo };
}

function adeptosIdolScore(team, p) {
  const b = team.balneario;
  const anos = b && b.presenca && b.presenca[p.id] ? Math.max(0, (balnearioAgoMs() - b.presenca[p.id]) / (365.25 * 86400000)) : 0;
  let s = overall(p) + (p.reputacaoJogador || 0) * 0.08 + Math.min(anos, 6) * 0.4;
  if (p.clubeFormadorId === team.id) s += 2;
  if (typeof balnearioIsCaptain === "function" && balnearioIsCaptain(team, p)) s += 1.5;
  return s;
}
function adeptosTop3(team) {
  return (team.players || []).filter(p => p && !p.__provisional && !p.emprestimo)
    .sort((x, y) => adeptosIdolScore(team, y) - adeptosIdolScore(team, x)).slice(0, 3);
}

function ensureAdeptos(team) {
  if (!adeptosElegivel(team)) return null;
  if (team.adeptos && team.adeptos.v === 1 && typeof team.adeptos.humor === "number") return team.adeptos;
  initClubFinance(team);
  const ref = adeptosQuotaRef(team);
  const sociosRef = adeptosSociosRef(team);
  const f = adeptosFatores(team);
  const ruido = (balnearioHash01("adeptos-a-" + team.id) + balnearioHash01("adeptos-b-" + team.id) - 1) * 24;
  const humor = clamp(f.alvo + ruido, 14, 90);
  team.adeptos = {
    v: 1, humor, refMes: humor, socios: sociosRef, sociosAnt: sociosRef, sociosRef,
    quotaOpcao: "normal", quotaMensal: ref, ultimaMudancaQuota: null,
    campanha: null, campanhaBonus: 0, ultimaCampanha: null, ultimaCampanhaResultado: null,
    ultimaClaque: null, ultimaClaqueResultado: null,
    idolosIds: adeptosTop3(team).map(p => p.id),
    nomesIdolos: Object.fromEntries(adeptosTop3(team).map(p => [p.id, p.name])),
    plantelIds: (team.players || []).filter(p => p && !p.__provisional).map(p => p.id),
    eventos: [], ultimoNivel: adeptosNivel(humor).id,
  };
  return team.adeptos;
}

function adeptosRegistarEvento(a, tom, texto) {
  a.eventos = a.eventos || [];
  a.eventos.unshift({ tom, texto, data: isoDate(state.currentDate) });
  if (a.eventos.length > 6) a.eventos.length = 6;
}

// Chegadas e saídas de ídolos / contratações sonantes, onde quer que tenham acontecido.
function adeptosSyncIdolos(team) {
  const a = ensureAdeptos(team);
  if (!a) return null;
  const squad = (team.players || []).filter(p => p && !p.__provisional);
  const ids = new Set(squad.map(p => p.id));
  const prevSquad = new Set(a.plantelIds || []);
  const prevIdolos = a.idolosIds || [];
  const top3 = adeptosTop3(team);
  const isUser = team.id === state.userTeamId;
  let delta = 0;
  const textos = [];
  prevIdolos.forEach((id, rank) => {
    if (ids.has(id)) return;
    const d = rank === 0 ? -8 : -5;
    delta += d;
    const nome = (a.nomesIdolos && a.nomesIdolos[id]) || "Um dos ídolos da casa";
    textos.push({ tom: "neg", texto: `A saída de ${nome} caiu mal nas bancadas` });
  });
  top3.forEach((p, rank) => {
    if (prevSquad.has(p.id) || prevIdolos.includes(p.id)) return;
    delta += rank <= 1 ? 3.5 : 2;
    textos.push({ tom: "pos", texto: `A chegada de ${p.name} animou os adeptos` });
  });
  delta = clamp(delta, -12, 6);
  if (delta !== 0) {
    a.humor = clamp(a.humor + delta, 3, 99);
    textos.slice(0, 2).forEach(t => adeptosRegistarEvento(a, t.tom, t.texto));
    if (isUser && Math.abs(delta) >= 3.5 && typeof pushNews === "function") {
      pushNews(state.currentDate, textos.map(t => t.texto).slice(0, 2).join(". ") + ".", "evento", delta < 0 ? "Adeptos reagem a uma saída" : "Adeptos animados com um reforço", { teamId: team.id });
    }
  }
  a.idolosIds = top3.map(p => p.id);
  a.nomesIdolos = {}; top3.forEach(p => { a.nomesIdolos[p.id] = p.name; });
  a.plantelIds = Array.from(ids);
  return a;
}

// Resultado de um jogo (chamado depois de recentResults já ter o novo resultado).
function registerAdeptosResult(team, side, res, goalDiff, oppId) {
  if (!adeptosElegivel(team)) return;
  const a = ensureAdeptos(team);
  if (!a) return;
  const casa = side === "home";
  let d = res === "V" ? (casa ? 1.7 : 1.2) : res === "D" ? (casa ? -2.0 : -1.3) : (casa ? -0.3 : 0.2);
  const last3 = (team.recentResults || []).slice(-3);
  if (last3.length === 3 && last3.every(x => x === "V")) d += 1.2;
  if (last3.length === 3 && last3.every(x => x === "D")) d -= 1.6;
  if (res === "D" && goalDiff <= -4) d -= 1.5;
  if (res === "V" && goalDiff >= 5) d += 0.8;
  try {
    if (oppId && typeof isDerby === "function" && isDerby(team.id, oppId)) d += (res === "V" ? 1.2 : res === "D" ? -1.5 : 0) * (typeof derbyIntensidade === "function" ? derbyIntensidade(team.id, oppId) * (0.85 + 0.45 * derbyFebre(team.id, oppId) / 100) : 1);
  } catch (e) {}
  const longe = Math.abs(a.humor - 50) / 50;
  if ((d > 0 && a.humor > 50) || (d < 0 && a.humor < 50)) d *= 1 - longe * 0.5;
  a.humor = clamp(a.humor + d, 3, 99);
}

// Efeitos no motor e na bilheteira (O(1), só lêem o valor guardado).
function adeptosHomeFactor(team) {
  const a = team && team.adeptos;
  if (!a || typeof a.humor !== "number") return 1;
  return 1 + clamp((a.humor - 50) / 50, -1, 1) * ADEPTOS_FATOR_CASA_MAX;
}
function adeptosAttendanceFactor(team) {
  const a = team && team.adeptos;
  if (!a || typeof a.humor !== "number") return 1;
  return 0.94 + 0.12 * (a.humor / 100);
}
// Receita mensal de quotas: sócios × preço (com a calibração como recurso quando o clube ainda não tem adeptos).
function adeptosQuotaIncome(team, calibrada) {
  const a = team && team.adeptos;
  if (!a || typeof a.socios !== "number") return calibrada;
  return Math.max(0, Math.round(a.socios * a.quotaMensal));
}

function adeptosSociosAlvo(team, a) {
  const ref = adeptosQuotaRef(team);
  const humorMult = 0.82 + 0.36 * (a.humor / 100);
  const e = 1.15 - 0.6 * (a.humor / 100); // adeptos felizes toleram melhor quotas mais altas
  const r = a.quotaMensal / ref;
  const priceMult = clamp(1 - e * (r - 1), 0.4, 1.3);
  return a.sociosRef * humorMult * priceMult + a.sociosRef * (a.campanhaBonus || 0);
}

// Actualização mensal (chamada por processMonthlyFinances, antes de cobrar as quotas).
function updateAdeptosMonthly(team) {
  const a = ensureAdeptos(team);
  if (!a) return;
  adeptosSyncIdolos(team);
  const f = adeptosFatores(team);
  a.refMes = a.humor;
  a.humor = clamp(a.humor + (f.alvo - a.humor) * 0.28, 3, 99);
  a.sociosRef = adeptosSociosRef(team);
  // 2026-10-16: a quota segue a divisão (sociosRef já seguia) — recalcula-se a partir da opção escolhida.
  {
    const opQ = ADEPTOS_QUOTA_OPCOES.find(o => o.id === a.quotaOpcao);
    if (opQ) a.quotaMensal = Math.max(0.5, Math.round(adeptosQuotaRef(team) * opQ.mult * 10) / 10);
  }
  const hoje = state.currentDate;
  const isUser = team.id === state.userTeamId;
  if (a.campanha && hoje >= new Date(a.campanha.resolveEm)) {
    const sucesso = Math.random() < clamp(0.6 + (a.humor - 50) / 150, 0.3, 0.85);
    const bonus = sucesso ? 0.06 + Math.random() * 0.1 : Math.random() * 0.02;
    a.campanhaBonus = bonus;
    const novos = Math.round(a.sociosRef * bonus);
    a.ultimaCampanhaResultado = { data: isoDate(hoje), sucesso, novos };
    if (isUser && typeof pushNews === "function") {
      pushNews(state.currentDate, sucesso
        ? `A campanha de sócios correu bem: cerca de ${novos} novos sócios aderiram ao ${teamLinkHtml(team.id)}.`
        : `A campanha de sócios teve pouco eco: só cerca de ${novos} novos sócios aderiram ao ${teamLinkHtml(team.id)}.`, "sistema", "Campanha de sócios", { teamId: team.id });
    }
    a.campanha = null;
  } else {
    a.campanhaBonus = (a.campanhaBonus || 0) * 0.88;
  }
  a.sociosAnt = a.socios;
  a.socios = Math.max(10, Math.round(a.socios + (adeptosSociosAlvo(team, a) - a.socios) * 0.2));
  const nivel = adeptosNivel(a.humor);
  if (isUser && a.ultimoNivel && a.ultimoNivel !== nivel.id && typeof pushNews === "function") {
    const ordem = ADEPTOS_NIVEIS.map(n => n.id).reverse();
    const subiu = ordem.indexOf(nivel.id) > ordem.indexOf(a.ultimoNivel);
    const razao = adeptosRazoes(team, a).find(r => r.tom === (subiu ? "pos" : "neg"));
    pushNews(state.currentDate, subiu
      ? `O ambiente nas bancadas melhorou: ${nivel.label.toLowerCase()}.${razao ? " " + razao.texto + "." : ""}`
      : `O ambiente nas bancadas piorou: ${nivel.label.toLowerCase()}.${razao ? " " + razao.texto + "." : ""}`, "evento", "Ambiente nas bancadas", { teamId: team.id });
  }
  a.ultimoNivel = nivel.id;
}

function adeptosRazoes(team, a) {
  const f = adeptosFatores(team);
  const cand = [];
  const add = (mag, tom, texto) => cand.push({ mag: Math.abs(mag), tom, texto });
  if (f.expect > 0.35) add(f.expect, "pos", "A equipa está acima do que se esperava");
  if (f.expect < -0.35) add(f.expect, "neg", "A equipa está abaixo do objetivo da época");
  if (f.forma > 0.6) add(f.forma, "pos", "Boa fase de resultados");
  if (f.forma < -0.4) add(f.forma + 0.2, "neg", "Os maus resultados pesam nas bancadas");
  const hoje = state.currentDate ? state.currentDate.getTime() : Date.now();
  (a.eventos || []).forEach(e => {
    const idade = (hoje - new Date(e.data).getTime()) / 86400000;
    if (idade <= 75) add(0.9, e.tom, e.texto);
  });
  const ref = adeptosQuotaRef(team), r = a.quotaMensal / ref;
  if (r >= 1.15 && a.humor < 55) add(0.5, "neg", "Quotas consideradas caras para o momento");
  if (r <= 0.88) add(0.4, "pos", "Quotas acessíveis agradam aos sócios");
  const pos = cand.filter((x, i, arr) => arr.findIndex(y => y.texto === x.texto) === i);
  return pos.sort((x, y) => y.mag - x.mag).slice(0, 4);
}

function adeptosInfo(team) {
  const a = adeptosSyncIdolos(team) || ensureAdeptos(team);
  if (!a) return null;
  const nivel = adeptosNivel(a.humor);
  const delta = a.humor - (a.refMes != null ? a.refMes : a.humor);
  const tendencia = delta > 2.5 ? "melhorar" : delta < -2.5 ? "piorar" : "estavel";
  const dSoc = a.sociosAnt ? (a.socios - a.sociosAnt) / a.sociosAnt : 0;
  const tendSocios = dSoc > 0.012 ? "crescer" : dSoc < -0.012 ? "descer" : "estavel";
  return { a, nivel, tendencia, tendSocios, razoes: adeptosRazoes(team, a) };
}

// ---------------------------------------------------------------- Ações
function adeptosDiasDesde(iso) {
  if (!iso) return Infinity;
  return Math.floor((balnearioAgoMs() - new Date(iso).getTime()) / 86400000);
}
function adeptosAcaoEspera(a, campo, cooldown) {
  const d = adeptosDiasDesde(a[campo]);
  return d >= cooldown ? { ok: true, dias: 0 } : { ok: false, dias: cooldown - d };
}

function setAdeptosQuota(team, opcaoId) {
  const a = ensureAdeptos(team);
  const op = ADEPTOS_QUOTA_OPCOES.find(o => o.id === opcaoId);
  if (!a || !op) return { ok: false, reason: "Opção inválida." };
  if (op.id === a.quotaOpcao) return { ok: false, reason: "Essa já é a quota atual." };
  const esp = adeptosAcaoEspera(a, "ultimaMudancaQuota", ADEPTOS_QUOTA_COOLDOWN_DIAS);
  if (!esp.ok) return { ok: false, reason: `Só podes voltar a mexer nas quotas daqui a ${esp.dias} dia${esp.dias === 1 ? "" : "s"}.` };
  const ordem = ADEPTOS_QUOTA_OPCOES.map(o => o.id);
  const passos = ordem.indexOf(op.id) - ordem.indexOf(a.quotaOpcao);
  const ref = adeptosQuotaRef(team);
  a.quotaOpcao = op.id;
  a.quotaMensal = Math.max(0.5, Math.round(ref * op.mult * 10) / 10);
  a.ultimaMudancaQuota = isoDate(state.currentDate);
  // Reação imediata: subir quotas irrita (mais ainda quando o ambiente já é mau); baixá-las agrada.
  if (passos > 0) {
    const d = -(a.humor < 50 ? 2.5 : 1.2) * passos;
    a.humor = clamp(a.humor + d, 3, 99);
    adeptosRegistarEvento(a, "neg", "O aumento das quotas não caiu bem");
  } else {
    a.humor = clamp(a.humor + 1.5 * -passos, 3, 99);
    adeptosRegistarEvento(a, "pos", "A descida das quotas foi bem recebida");
  }
  return { ok: true, quota: a.quotaMensal };
}

function adeptosCampanhaCusto(team) {
  const a = ensureAdeptos(team);
  return Math.max(1500, Math.round((a.socios * a.quotaMensal * 2) / 100) * 100);
}
function iniciarAdeptosCampanha(team) {
  const a = ensureAdeptos(team);
  if (!a) return { ok: false, reason: "Sem adeptos." };
  if (a.campanha) return { ok: false, reason: "Já há uma campanha de sócios em curso." };
  const esp = adeptosAcaoEspera(a, "ultimaCampanha", ADEPTOS_CAMPANHA_COOLDOWN_DIAS);
  if (!esp.ok) return { ok: false, reason: `Só podes lançar nova campanha daqui a ${esp.dias} dia${esp.dias === 1 ? "" : "s"}.` };
  initClubFinance(team);
  if (team.financeiro.restricoesInsolvencia) return { ok: false, reason: "O clube está sob intervenção financeira e não pode pagar uma campanha." };
  const custo = adeptosCampanhaCusto(team);
  if ((team.financeiro.saldo || 0) < custo) return { ok: false, reason: "Saldo insuficiente para pagar a campanha." };
  addFinanceMovement(team, "despesa", "Marketing", "Campanha de angariação de sócios", custo, state.currentDate);
  a.campanha = { resolveEm: isoDate(addDays(state.currentDate, 28)), custo };
  a.ultimaCampanha = isoDate(state.currentDate);
  return { ok: true, custo };
}

function adeptosClaqueProxima(team, a) {
  a = a || ensureAdeptos(team);
  const esp = adeptosAcaoEspera(a, "ultimaClaque", ADEPTOS_CLAQUE_COOLDOWN_DIAS);
  if (!esp.ok) return { ok: false, dias: esp.dias, motivo: "espera" };
  if (a.humor >= 46) return { ok: false, dias: 0, motivo: "sem-crise" };
  return { ok: true, dias: 0 };
}
function reunirComClaque(team) {
  const a = ensureAdeptos(team);
  if (!a) return { ok: false, reason: "Sem adeptos." };
  const prox = adeptosClaqueProxima(team, a);
  if (!prox.ok) return { ok: false, reason: prox.motivo === "espera" ? `Só podes voltar a reunir com a claque daqui a ${prox.dias} dia${prox.dias === 1 ? "" : "s"}.` : "A claque só pede reunião quando o ambiente está a azedar." };
  const last3 = (team.recentResults || []).slice(-3);
  const mauMomento = last3.length === 3 && last3.every(x => x === "D");
  let d, texto;
  if (mauMomento && Math.random() < 0.25) {
    d = -1.0; texto = "A reunião foi tensa: a claque saiu pouco convencida e mantém as críticas.";
  } else if (mauMomento) {
    d = 1.5 + Math.random() * 1.5; texto = "A conversa foi dura, mas a claque reconheceu o esforço e concedeu mais algum tempo à equipa.";
  } else {
    d = 3 + Math.random() * 3; texto = "A reunião acalmou os ânimos: a claque voltou a apoiar a equipa com mais confiança.";
  }
  a.humor = clamp(a.humor + d, 3, 99);
  a.ultimaClaque = isoDate(state.currentDate);
  a.ultimaClaqueResultado = { data: isoDate(state.currentDate), texto };
  return { ok: true, texto };
}

// ---------------------------------------------------------------- Interface (Resumo do Clube)
function adeptosTendenciaHtml(t) {
  if (t === "melhorar") return '<span class="bal-trend bal-trend-up" title="O ambiente está a melhorar">▲ a melhorar</span>';
  if (t === "piorar") return '<span class="bal-trend bal-trend-down" title="O ambiente está a piorar">▼ a piorar</span>';
  return '<span class="bal-trend bal-trend-flat" title="O ambiente mantém-se estável">▬ estável</span>';
}
function adeptosSociosTendenciaHtml(t) {
  if (t === "crescer") return '<span class="bal-trend bal-trend-up">▲ a crescer</span>';
  if (t === "descer") return '<span class="bal-trend bal-trend-down">▼ a descer</span>';
  return '<span class="bal-trend bal-trend-flat">▬ estável</span>';
}
function renderAdeptosPanel() {
  const el = document.getElementById("adeptosPanel");
  if (!el) return;
  const mine = typeof myTeam === "function" ? myTeam() : null;
  const info = mine ? adeptosInfo(mine) : null;
  if (!info) { el.classList.add("hidden"); el.innerHTML = ""; return; }
  el.classList.remove("hidden");
  const a = info.a;
  const razoes = info.razoes.length
    ? info.razoes.map(r => `<span class="bal-chip bal-chip-${r.tom}">${r.tom === "pos" ? "＋" : "−"} ${escapeHtml(r.texto)}</span>`).join("")
    : '<span class="bal-chip">Sem factores de destaque</span>';
  const opQuota = ADEPTOS_QUOTA_OPCOES.find(o => o.id === a.quotaOpcao) || ADEPTOS_QUOTA_OPCOES[2];
  const espQuota = adeptosAcaoEspera(a, "ultimaMudancaQuota", ADEPTOS_QUOTA_COOLDOWN_DIAS);
  const espCamp = adeptosAcaoEspera(a, "ultimaCampanha", ADEPTOS_CAMPANHA_COOLDOWN_DIAS);
  const campOk = espCamp.ok && !a.campanha;
  const campTitle = a.campanha ? "Já há uma campanha em curso" : espCamp.ok ? `Custa ${fmtMoney(adeptosCampanhaCusto(mine))}` : `Podes lançar nova campanha daqui a ${espCamp.dias} dia${espCamp.dias === 1 ? "" : "s"}`;
  const claque = adeptosClaqueProxima(mine, a);
  const claqueTitle = claque.ok ? "Reunir com a claque" : claque.motivo === "espera" ? `Podes voltar a reunir daqui a ${claque.dias} dia${claque.dias === 1 ? "" : "s"}` : "A claque só pede reunião quando o ambiente azeda";
  const ultCamp = a.ultimaCampanhaResultado;
  const ultClaque = a.ultimaClaqueResultado;
  el.innerHTML = `
    <div class="eyebrow section-label">Adeptos e sócios</div>
    <div class="bal-head">
      <span class="bal-dot" style="background:${info.nivel.cor};"></span>
      <b class="bal-label">${info.nivel.label}</b>
      ${adeptosTendenciaHtml(info.tendencia)}
    </div>
    <div class="bal-text">${escapeHtml(info.nivel.texto)}</div>
    <div class="bal-chips">${razoes}</div>
    <div class="bal-actions">
      <span class="bal-cap">Sócios: <b>${a.socios.toLocaleString("pt-PT")}</b> ${adeptosSociosTendenciaHtml(info.tendSocios)}</span>
      <span class="bal-cap">Quota: <b>${adeptosFmtQuota(a.quotaMensal)}</b>/mês <span class="helptext" style="display:inline;">(${opQuota.label.toLowerCase()})</span></span>
    </div>
    <div class="bal-actions">
      <button class="btn btn-ghost bal-btn" id="adpQuotaBtn" title="${espQuota.ok ? "Alterar o preço das quotas" : `Só podes mexer nas quotas daqui a ${espQuota.dias} dia${espQuota.dias === 1 ? "" : "s"}`}">Preço das quotas</button>
      <button class="btn btn-ghost bal-btn" id="adpCampanhaBtn" ${campOk ? "" : "disabled"} title="${campTitle}">Campanha de sócios</button>
      <button class="btn btn-ghost bal-btn" id="adpClaqueBtn" ${claque.ok ? "" : "disabled"} title="${claqueTitle}">Reunir com a claque</button>
    </div>
    ${a.campanha ? `<div class="bal-last helptext">Campanha de sócios em curso — o resultado conhece-se daqui a umas semanas.</div>` : ""}
    ${ultCamp ? `<div class="bal-last helptext">Última campanha (${fmtDateShort(ultCamp.data)}): ${ultCamp.sucesso ? "correu bem" : "teve pouco eco"}, cerca de ${ultCamp.novos} novos sócios.</div>` : ""}
    ${ultClaque ? `<div class="bal-last helptext">Última reunião com a claque (${fmtDateShort(ultClaque.data)}): ${escapeHtml(ultClaque.texto)}</div>` : ""}`;
}

function openAdeptosQuotaModal() {
  const mine = myTeam(); const a = ensureAdeptos(mine); if (!a) return;
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = "Preço das quotas";
  const ref = adeptosQuotaRef(mine);
  const esp = adeptosAcaoEspera(a, "ultimaMudancaQuota", ADEPTOS_QUOTA_COOLDOWN_DIAS);
  const rows = ADEPTOS_QUOTA_OPCOES.map(o => {
    const preco = Math.max(0.5, Math.round(ref * o.mult * 10) / 10);
    const cur = o.id === a.quotaOpcao;
    return `<div class="internal-player-row"><div><b>${o.label}</b><div class="meta">${adeptosFmtQuota(preco)} por sócio, por mês</div></div><div></div><button class="btn ${cur ? "btn-primary" : "btn-ghost"} adp-set-quota" data-id="${o.id}" ${cur || !esp.ok ? "disabled" : ""}>${cur ? "Atual" : "Escolher"}</button></div>`;
  }).join("");
  m.querySelector("#balnearioModalBody").innerHTML = `<p class="helptext" style="margin-bottom:8px;">Quotas mais altas rendem mais por sócio, mas afastam alguns — e os adeptos toleram pior o aumento quando o ambiente é mau. Baixá-las agrada à massa adepta e atrai sócios, à custa de receita. Só podes mexer nas quotas de três em três meses.${esp.ok ? "" : ` Faltam ${esp.dias} dia${esp.dias === 1 ? "" : "s"}.`}</p>
    <div id="adpModalErr" class="helptext" style="color:#d6402f;"></div>${rows}`;
  m.classList.remove("hidden");
}
function openAdeptosCampanhaModal() {
  const mine = myTeam(); const a = ensureAdeptos(mine); if (!a) return;
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = "Campanha de sócios";
  m.querySelector("#balnearioModalBody").innerHTML = `<p class="helptext" style="margin-bottom:10px;">Lanças uma campanha de angariação de sócios. Custa <b>${fmtMoney(adeptosCampanhaCusto(mine))}</b> e o resultado só se conhece daqui a umas quatro semanas. Corre melhor quando os adeptos estão contentes e pode ficar aquém do esperado. Só podes lançar uma campanha de quatro em quatro meses.</p>
    <div id="adpModalErr" class="helptext" style="color:#d6402f;"></div>
    <div class="modal-actions"><button class="btn btn-primary" id="adpConfirmCampanha">Lançar campanha</button></div>`;
  m.classList.remove("hidden");
}
function openAdeptosClaqueModal() {
  const mine = myTeam(); const a = ensureAdeptos(mine); if (!a) return;
  const m = balnearioModalEl();
  m.querySelector("#balnearioModalTitle").textContent = "Reunir com a claque";
  m.querySelector("#balnearioModalBody").innerHTML = `<p class="helptext" style="margin-bottom:10px;">Sentas-te com os representantes da claque para acalmar os ânimos. É um gesto simbólico: o efeito é limitado e, se a equipa estiver numa má série, pode correr mal. Só podes voltar a fazê-lo passados 45 dias.</p>
    <div id="adpModalErr" class="helptext" style="color:#d6402f;"></div><div id="adpClaqueResultado" style="margin-top:10px;"></div>
    <div class="modal-actions"><button class="btn btn-primary" id="adpConfirmClaque">Reunir</button></div>`;
  m.classList.remove("hidden");
}
(function wireAdeptosUi() {
  document.addEventListener("click", e => {
    const t = e.target;
    if (!t || !t.closest) return;
    if (t.closest("#adpQuotaBtn")) { openAdeptosQuotaModal(); return; }
    if (t.closest("#adpCampanhaBtn")) { openAdeptosCampanhaModal(); return; }
    if (t.closest("#adpClaqueBtn")) { openAdeptosClaqueModal(); return; }
    const q = t.closest(".adp-set-quota");
    if (q) {
      const r = setAdeptosQuota(myTeam(), q.getAttribute("data-id"));
      if (!r.ok) { const err = document.getElementById("adpModalErr"); if (err) err.textContent = r.reason; return; }
      balnearioModalEl().classList.add("hidden"); renderAdeptosPanel();
      showTransientNotice(`Quota fixada em ${adeptosFmtQuota(r.quota)} por mês.`);
      return;
    }
    if (t.closest("#adpConfirmCampanha")) {
      const r = iniciarAdeptosCampanha(myTeam());
      if (!r.ok) { const err = document.getElementById("adpModalErr"); if (err) err.textContent = r.reason; return; }
      balnearioModalEl().classList.add("hidden"); renderAdeptosPanel();
      showTransientNotice(`Campanha de sócios lançada (${fmtMoney(r.custo)}).`);
      return;
    }
    if (t.closest("#adpConfirmClaque")) {
      const r = reunirComClaque(myTeam());
      if (!r.ok) { const err = document.getElementById("adpModalErr"); if (err) err.textContent = r.reason; return; }
      const out = document.getElementById("adpClaqueResultado");
      if (out) out.innerHTML = `<div class="pm-postmatch-grid"><div>${escapeHtml(r.texto)}</div></div>`;
      const btn = document.getElementById("adpConfirmClaque"); if (btn) btn.disabled = true;
      renderAdeptosPanel();
    }
  });
})();
