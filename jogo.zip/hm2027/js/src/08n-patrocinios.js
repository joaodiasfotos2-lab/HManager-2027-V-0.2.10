// Patrocínios negociáveis (2026-10-12, pedido do utilizador: "Patrocínios negociáveis").
// Decisões de desenho confirmadas por ele:
//  - ESTRUTURA: vários patrocinadores por categoria — principal (camisola), técnico (equipamento),
//    pavilhão (naming) e até 3 parceiros locais — cada um com valor, duração e cláusulas próprias;
//  - NEGOCIÁVEL: valor anual, duração (1–5 épocas), objetivos e bónus (valor fixo ou variável com
//    bónus por objetivo/título/Europa; cláusula de descida) e exclusividade/exposição;
//  - COMO SURGEM E ACABAM: propostas de empresas por email, procura ativa pelo departamento
//    comercial (custo e prazo, resultado incerto), renovação perto do fim do contrato e saída por
//    incumprimento (satisfação do patrocinador baixa → aviso → rescisão);
//  - IA: todos os clubes têm os mesmos contratos, renovações, bónus e saídas, decididos
//    automaticamente (sem emails nem negociação detalhada).
//
// Ligação ao modelo financeiro existente (04-financas.js): o total dos contratos ativos continua a
// alimentar financeiro.receitaMensalPatrocinio (e toda a calibração que já existe sobre ele). A
// sincronização faz-se por DIFERENÇA (patrocinioSync): quando um contrato entra, sai ou muda de
// valor, só a diferença é somada ao total mensal — assim o adiantamento de patrocínio e a adaptação
// à mudança de divisão (que mexem diretamente nesse total) continuam a funcionar sem conflitos. Na
// mudança de divisão os contratos escalam na mesma proporção (patrocinioEscalar).
//
// Tudo o que não vem de regulamento é ESTIMATIVA do jogo: repartição do valor por categoria
// (55/15/12/3×6%), descontos por duração, ajustes por cláusula, margens de negociação, bónus,
// probabilidades de propostas, custo da procura ativa e penalização de rescisão.

const PAT_CATEGORIAS = {
  principal: { label: "Principal (camisola)", share: 0.55, slots: 1 },
  tecnico:   { label: "Técnico (equipamento)", share: 0.15, slots: 1 },
  naming:    { label: "Pavilhão (naming)", share: 0.12, slots: 1 },
  local:     { label: "Parceiro local", share: 0.06, slots: 3 },
};
const PAT_ORDEM = ["principal", "tecnico", "naming", "local"];
const PAT_DURACAO_MULT = { 1: 1.06, 2: 1.03, 3: 1.0, 4: 0.97, 5: 0.94 };     // curto paga mais por época
const PAT_VARIAVEL_MULT = 0.85;                                                 // parte fixa de um contrato variável
const PAT_BONUS_OBJETIVO = 0.35, PAT_BONUS_TITULO = 0.18, PAT_BONUS_EUROPA = 0.12;   // × parte fixa
const PAT_DESCIDA_MULT = { nenhuma: 1.0, reduz: 1.04, rescinde: 1.08 };
const PAT_DESCIDA_REDUZ = 0.6;                                                  // valor que resta após descida (cláusula "reduz")
const PAT_EXCLUSIVO_MULT = 1.06;
const PAT_EXPOSICAO_MULT = [1.0, 1.08, 1.15];
const PAT_EXPOSICAO_LABEL = ["Normal", "Reforçada (nome em destaque)", "Máxima (camisola e pavilhão, TV)"];
const PAT_EXPOSICAO_HUMOR = 0.25;       // humor dos adeptos por mês com exposição máxima (excesso de comercialização)
const PAT_TV_BONUS_POR_NIVEL = 0.5;     // +50% do bónus de TV por nível de exposição
const PAT_TV_INTERESSE_POR_NIVEL = 4;   // pontos de interesse televisivo por nível de exposição
const PAT_PROPOSTA_DIAS = 20;
const PAT_PROCURA_DIAS = 21;
const PAT_RONDAS_MAX = 3;
const PAT_SAT_BAIXA = 22, PAT_SAT_AVISO_DIAS = 60;
const PAT_RESCISAO_FRAC = 0.4;          // × valor anual × épocas por cumprir (máx. 3)

const PAT_SETORES = {
  banca: ["Banco {c}", "Caixa de Crédito de {c}"],
  seguros: ["Seguros {c}", "Mútua de {c}"],
  energia: ["Energias de {c}", "Gás & Luz {c}"],
  telecom: ["Telecom {c}", "Fibra {c}"],
  construcao: ["Construções {c}", "Imobiliária {c}"],
  retalho: ["Supermercados {c}", "Centro Comercial {c}"],
  automovel: ["Auto {c}", "Stand {c}"],
  saude: ["Clínica {c}", "Farmácias {c}"],
  bebidas: ["Cervejeira {c}", "Águas de {c}"],
  equipamento: ["Equipamentos {c} Sport", "Sportline {c}"],
  outro: ["Grupo {c}"],
};
const PAT_SETORES_GERAIS = ["banca", "seguros", "energia", "telecom", "construcao", "retalho", "automovel", "saude", "bebidas"];
const PAT_SETOR_ROTULO = { banca: "Banca", seguros: "Seguros", energia: "Energia", telecom: "Telecomunicações", construcao: "Construção e imobiliário",
  retalho: "Retalho", automovel: "Automóvel", saude: "Saúde", bebidas: "Bebidas", equipamento: "Equipamento desportivo", outro: "Outro" };
// Patrocinadores reais já existentes no jogo (CLUB_FINANCE_PROFILES): setor aproximado.
const PAT_SETOR_REAIS = { "betano": "outro", "tap": "outro", "super bock": "bebidas", "adufe": "outro" };

function patElegivel(t){ return !!t && !!t.financeiro && !t.equipaPrincipalId && !t.selecaoNacional; }
function patEhUtilizador(t){ return !!t && t.id === state.userTeamId; }
function patIso(d){ return isoDate(new Date(d || state.currentDate)); }
function patFmt(iso){ try { return fmtDateShort(new Date(iso)); } catch(e){ return iso; } }
function patRound(n){ return Math.round(n / 10) * 10; }
function patCidade(team){ return String(team.cidadePavilhao || team.name || "").trim() || team.name; }
function patRng(team){ return calibrationSeededRandom(`pat|${team.id}|${(team.patrocinios && team.patrocinios.seq) || 0}|${state.season}`); }
function patRef(team){
  try { const c = financeConfig(team); return Math.max(12000, c.sponsorValorAnual || (c.sponsor || 0) * 12); } catch(e){ return Math.max(12000, (team.financeiro.sponsorValorAnual || 120000)); }
}

// ---------------------------------------------------------------------------------------------
// Dados
// ---------------------------------------------------------------------------------------------
function patNomeEmpresa(team, setor, usados){
  const rng = patRng(team); const base = PAT_SETORES[setor] || PAT_SETORES.outro;
  for(let i = 0; i < 8; i++){
    const t = base[Math.floor(rng() * base.length)].replace("{c}", patCidade(team));
    if(!usados.has(t)) return t;
  }
  return base[0].replace("{c}", patCidade(team)) + " II";
}
function patSetorLivre(team, categoria, exclusivos, usadosSetor, usadosNome){
  const lista = categoria === "tecnico" ? ["equipamento"] : PAT_SETORES_GERAIS.filter(s => !exclusivos.has(s));
  const livres = lista.filter(s => !usadosSetor.has(s));
  const pool = livres.length ? livres : lista.filter(s => !exclusivos.has(s));
  if(!pool.length) return null;
  const rng = patRng(team);
  return pool[Math.floor(rng() * pool.length)];
}
function patNovoId(team){ const p = team.patrocinios; p.seq = (p.seq || 0) + 1; return `${team.id}-p${p.seq}`; }

function patrocinioEnsure(team){
  if(!patElegivel(team)) return null;
  if(team.patrocinios && Array.isArray(team.patrocinios.contratos)) return team.patrocinios;
  const f = team.financeiro;
  const total = Math.max(0, (f.receitaMensalPatrocinio || 0) * 12);
  team.patrocinios = { v: 1, contratos: [], propostas: [], procura: null, seq: 0, totalAplicado: 0, avisosEnviados: 0 };
  if(total <= 0){ return team.patrocinios; }
  const rng = patRng(team);
  const usadosSetor = new Set(), usadosNome = new Set();
  const realNome = f.sponsorNome && !/^Patrocinador Principal do /i.test(f.sponsorNome) ? f.sponsorNome : null;
  PAT_ORDEM.forEach(cat => {
    const cfg = PAT_CATEGORIAS[cat];
    for(let i = 0; i < cfg.slots; i++){
      let setor, empresa;
      if(cat === "principal" && realNome){
        setor = PAT_SETOR_REAIS[realNome.toLowerCase()] || "outro"; empresa = realNome;
      } else {
        setor = patSetorLivre(team, cat, new Set(), usadosSetor, usadosNome) || "outro";
        empresa = patNomeEmpresa(team, setor, usadosNome);
      }
      usadosSetor.add(setor); usadosNome.add(empresa);
      const valor = Math.round(total * cfg.share);
      const restam = Math.floor(rng() * 4);               // 0–3 épocas depois da atual: fins escalonados
      team.patrocinios.contratos.push({
        id: patNovoId(team), categoria: cat, empresa, setor, valorAnual: valor, inicio: state.season - 1, fim: state.season + restam,
        modelo: "fixo", descida: "nenhuma", exclusivo: false, exposicao: 0, sat: 60, aviso: null, origem: "inicial", estado: "ativo",
      });
    }
  });
  team.patrocinios.totalAplicado = team.patrocinios.contratos.reduce((a, c) => a + c.valorAnual, 0);
  return team.patrocinios;
}
function patContratos(team){ const p = patrocinioEnsure(team); return p ? p.contratos.filter(c => c.estado === "ativo") : []; }
function patSlotsLivres(team){
  const ativos = patContratos(team); const out = {};
  PAT_ORDEM.forEach(cat => { out[cat] = PAT_CATEGORIAS[cat].slots - ativos.filter(c => c.categoria === cat).length; });
  return out;
}
function patExclusivos(team){ return new Set(patContratos(team).filter(c => c.exclusivo).map(c => c.setor)); }

// Soma por diferença ao total mensal do clube (ver cabeçalho).
function patrocinioSync(team){
  const p = patrocinioEnsure(team); if(!p) return;
  const f = team.financeiro;
  const total = p.contratos.filter(c => c.estado === "ativo").reduce((a, c) => a + c.valorAnual, 0);
  const delta = total - (p.totalAplicado || 0);
  if(delta){
    f.receitaMensalPatrocinio = Math.max(0, Math.round((f.receitaMensalPatrocinio || 0) + delta / 12));
    f.sponsorValorAnual = Math.max(0, Math.round((f.sponsorValorAnual || 0) + delta));
  }
  p.totalAplicado = total;
  const principal = p.contratos.find(c => c.estado === "ativo" && c.categoria === "principal");
  if(principal) f.sponsorNome = principal.empresa;
}
// Mudança de divisão: todos os contratos escalam como o total (04-financas.js já escalou financeiro).
function patrocinioEscalar(team, ratio){
  if(!patElegivel(team)) return;
  if(!team.patrocinios){ patrocinioEnsure(team); return; }   // construído já com o total escalado
  const p = team.patrocinios;
  p.contratos.forEach(c => {
    if(c.estado !== "ativo") return;
    c.valorAnual = Math.max(1000, Math.round(c.valorAnual * ratio));
    // 2026-10-16: uma renovação já acordada (c.proxima) também muda de escala — senão, logo a seguir,
    // patrocinioFimDeEpoca repunha o valor da divisão antiga.
    if(c.proxima && c.proxima.valorAnual) c.proxima.valorAnual = Math.max(1000, Math.round(c.proxima.valorAnual * ratio));
  });
  p.totalAplicado = p.contratos.filter(c => c.estado === "ativo").reduce((a, c) => a + c.valorAnual, 0);
}

// ---------------------------------------------------------------------------------------------
// Preços e termos
// ---------------------------------------------------------------------------------------------
function patTermosPadrao(){ return { duracao: 3, modelo: "fixo", descida: "nenhuma", exclusivo: false, exposicao: 0 }; }
function patTermosMult(t){
  return (PAT_DURACAO_MULT[t.duracao] || 1) * (t.modelo === "variavel" ? PAT_VARIAVEL_MULT : 1)
    * (PAT_DESCIDA_MULT[t.descida] || 1) * (t.exclusivo ? PAT_EXCLUSIVO_MULT : 1) * (PAT_EXPOSICAO_MULT[t.exposicao] || 1);
}
// Sinais do clube que mexem no preço que as empresas aceitam pagar (0,8–1,3).
function patMomento(team){
  const a = typeof ensureAdeptos === "function" ? ensureAdeptos(team) : null;
  const humor = a ? a.humor : 50;
  const conf = team.confiancaDirecao != null ? team.confiancaDirecao : 60;
  const tv = (typeof tvEnsure === "function" && tvEnsure(team)) ? tvEnsure(team).jogos : 0;
  return clamp(0.92 + (humor - 50) * 0.0016 + (conf - 50) * 0.002 + Math.min(2, tv) * 0.03, 0.8, 1.3);
}
function patBase(team, categoria){ return patRef(team) * PAT_CATEGORIAS[categoria].share * patMomento(team); }
function patOferta(prop, termos){ return patRound(prop.base * patTermosMult(termos) * prop.lowball); }
function patMaximo(prop, termos){ return prop.base * patTermosMult(termos) * prop.margem; }

function patTermosTexto(c){
  const t = c.termos || c;
  const partes = [];
  partes.push(t.modelo === "variavel" ? `variável (bónus: +${Math.round(PAT_BONUS_OBJETIVO * 100)}% se cumprir o objetivo, +${Math.round(PAT_BONUS_TITULO * 100)}% título, +${Math.round(PAT_BONUS_EUROPA * 100)}% Europa)` : "fixo");
  if(t.descida === "reduz") partes.push(`desce para ${Math.round(PAT_DESCIDA_REDUZ * 100)}% se o clube descer`);
  if(t.descida === "rescinde") partes.push("rescinde se o clube descer");
  if(t.exclusivo) partes.push("exclusivo no setor");
  if(t.exposicao > 0) partes.push(`exposição ${PAT_EXPOSICAO_LABEL[t.exposicao].toLowerCase()}`);
  return partes.join(" · ");
}
function patEmailEmpresa(empresa){
  const slug = String(empresa || "patrocinio").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "patrocinio";
  return `comercial@${slug}.pt`;
}
function patNoticia(team, titulo, texto, empresa, stop){
  if(!patEhUtilizador(team)) return;
  pushNews(state.currentDate, texto, "patrocinio", titulo, { sender: patEmailEmpresa(empresa), autoAdvanceStop: !!stop });
}

// ---------------------------------------------------------------------------------------------
// Contratos
// ---------------------------------------------------------------------------------------------
function patAssinar(team, { categoria, empresa, setor, valor, termos, origem, inicio }){
  const p = patrocinioEnsure(team);
  const ini = inicio != null ? inicio : state.season;
  const c = {
    id: patNovoId(team), categoria, empresa, setor, valorAnual: Math.round(valor), inicio: ini, fim: ini + termos.duracao - 1,
    modelo: termos.modelo, descida: termos.descida, exclusivo: !!termos.exclusivo, exposicao: termos.exposicao || 0,
    sat: 65, aviso: null, origem: origem || "proposta", estado: "ativo",
  };
  p.contratos.push(c);
  patrocinioSync(team);
  return c;
}
function patEncerrar(team, c, motivo){
  c.estado = "terminado"; c.motivoFim = motivo; c.fimData = patIso();
  patrocinioSync(team);
}
function patrocinioRescindir(team, contratoId){
  const p = patrocinioEnsure(team); const c = p && p.contratos.find(x => x.id === contratoId && x.estado === "ativo");
  if(!c) return { ok: false, reason: "Contrato não encontrado." };
  const epocas = clamp(c.fim - state.season + 1, 1, 3);
  const multa = Math.round(c.valorAnual * PAT_RESCISAO_FRAC * epocas);
  addFinanceMovement(team, "despesa", "Patrocínio", `Indemnização pela rescisão do contrato com ${c.empresa}`, multa, state.currentDate);
  patEncerrar(team, c, "rescindido pelo clube");
  if(typeof ensureAdeptos === "function"){ /* sem efeito nos adeptos */ }
  return { ok: true, multa, empresa: c.empresa };
}

// ---------------------------------------------------------------------------------------------
// Propostas (utilizador): novas, por procura ativa e renovações
// ---------------------------------------------------------------------------------------------
function patNovaProposta(team, categoria, tipo, opts){
  opts = opts || {};
  const p = patrocinioEnsure(team); if(!p) return null;
  const rng = Math.random;
  let setor, empresa, termos = patTermosPadrao(), contratoId = null;
  if(tipo === "renovacao"){
    const c = p.contratos.find(x => x.id === opts.contratoId);
    if(!c) return null;
    setor = c.setor; empresa = c.empresa; contratoId = c.id;
    termos = { duracao: 3, modelo: c.modelo, descida: c.descida, exclusivo: c.exclusivo, exposicao: c.exposicao };
  } else {
    const usadosSetor = new Set(patContratos(team).map(c => c.setor));
    setor = patSetorLivre(team, categoria, patExclusivos(team), usadosSetor, null);
    if(!setor) return null;
    const usados = new Set(p.contratos.map(c => c.empresa).concat(p.propostas.map(x => x.empresa)));
    empresa = patNomeEmpresa(team, setor, usados);
  }
  const ativa = opts.ativa;
  const prop = {
    id: patNovoId(team), tipo, categoria, contratoId, empresa, setor,
    base: Math.round(patBase(team, categoria)), lowball: ativa ? 0.95 + rng() * 0.05 : 0.90 + rng() * 0.08, margem: ativa ? 1.10 + rng() * 0.12 : 1.06 + rng() * 0.12,
    ativa: !!ativa, termos, criada: patIso(), expira: patIso(new Date(new Date(state.currentDate).getTime() + PAT_PROPOSTA_DIAS * 86400000)), rondas: 0, contra: null,
  };
  p.propostas.push(prop);
  const cat = PAT_CATEGORIAS[categoria];
  const oferta = patOferta(prop, termos);
  patNoticia(team,
    tipo === "renovacao" ? `Renovação: ${empresa} quer continuar` : `Proposta de patrocínio: ${empresa}`,
    tipo === "renovacao"
      ? `A ${escapeHtml(empresa)} (${escapeHtml(cat.label.toLowerCase())}) propõe renovar o contrato que termina esta época: <b>${fmtMoney(oferta)} por época</b> por ${termos.duracao} épocas. Podes negociar valor, duração, bónus, cláusulas e exposição no painel da Direção, secção Patrocínios, até ${patFmt(prop.expira)}.`
      : `A ${escapeHtml(empresa)} (setor: ${escapeHtml(PAT_SETOR_ROTULO[setor] || setor)}) quer ser ${escapeHtml(cat.label.toLowerCase())} do ${escapeHtml(team.name)}: <b>${fmtMoney(oferta)} por época</b> por ${termos.duracao} épocas. Podes aceitar, contrapropor ou recusar no painel da Direção, secção Patrocínios, até ${patFmt(prop.expira)}.`,
    empresa, true);
  return prop;
}

function patResultadoEmail(team, prop, texto, titulo){ patNoticia(team, titulo, texto, prop.empresa, false); }

// acao: "contrapropor" (também serve para aceitar: valor <= oferta) | "recusar"
function patrocinioResponder(team, propId, acao, termos, valorPedido){
  const p = patrocinioEnsure(team); const i = p ? p.propostas.findIndex(x => x.id === propId) : -1;
  if(i < 0) return { ok: false, reason: "Esta proposta já não está disponível." };
  const prop = p.propostas[i];
  if(acao === "recusar"){
    p.propostas.splice(i, 1);
    return { ok: true, estado: "recusada", msg: `Proposta da ${prop.empresa} recusada.` };
  }
  const t = Object.assign(patTermosPadrao(), termos || prop.termos);
  t.duracao = clamp(Math.round(t.duracao), 1, 5);
  if(!(t.modelo === "fixo" || t.modelo === "variavel")) t.modelo = "fixo";
  if(!PAT_DESCIDA_MULT[t.descida]) t.descida = "nenhuma";
  t.exposicao = clamp(Math.round(t.exposicao || 0), 0, 2); t.exclusivo = !!t.exclusivo;
  const oferta = patOferta(prop, t), max = patMaximo(prop, t);
  const pedido = Math.max(1000, Math.round(Number(valorPedido) || oferta));
  // Verificações de slot e exclusividade no momento de assinar
  const fechar = (valor, termosFinais) => {
    if(prop.tipo === "nova"){
      if(patSlotsLivres(team)[prop.categoria] <= 0) { p.propostas.splice(i, 1); return { ok: false, reason: "Já não há vaga nesta categoria." }; }
      if(patExclusivos(team).has(prop.setor)){ p.propostas.splice(i, 1); return { ok: false, reason: "Um patrocinador exclusivo bloqueia este setor." }; }
      patAssinar(team, { categoria: prop.categoria, empresa: prop.empresa, setor: prop.setor, valor, termos: termosFinais, origem: prop.ativa ? "procura" : "proposta" });
    } else {
      const c = p.contratos.find(x => x.id === prop.contratoId && x.estado === "ativo");
      if(!c){ p.propostas.splice(i, 1); return { ok: false, reason: "O contrato original já não existe." }; }
      c.proxima = { valorAnual: Math.round(valor), termos: termosFinais };
      c.renovado = true;
    }
    p.propostas.splice(i, 1);
    return { ok: true, estado: "aceite", valor, msg: prop.tipo === "nova" ? `Contrato assinado com a ${prop.empresa}: ${fmtMoney(valor)} por época, ${termosFinais.duracao} épocas.` : `Renovação acordada com a ${prop.empresa}: ${fmtMoney(valor)} por época a partir da próxima época, ${termosFinais.duracao} épocas.` };
  };
  if(pedido <= oferta) return fechar(pedido === oferta ? oferta : pedido, t);
  if(prop.rondas >= PAT_RONDAS_MAX){
    p.propostas.splice(i, 1);
    patResultadoEmail(team, prop, `A ${escapeHtml(prop.empresa)} deu por terminadas as negociações: não chegámos a acordo no valor.`, `${prop.empresa} desistiu`);
    return { ok: true, estado: "desistiu", msg: "A empresa deu por terminadas as negociações." };
  }
  prop.rondas++;
  if(pedido > max * 1.15){
    p.propostas.splice(i, 1);
    patResultadoEmail(team, prop, `A ${escapeHtml(prop.empresa)} considerou o valor pedido (${fmtMoney(pedido)}) fora do seu orçamento e retirou a proposta.`, `${prop.empresa} retirou a proposta`);
    return { ok: true, estado: "desistiu", msg: "O valor pedido ficou muito acima do orçamento da empresa: a proposta foi retirada." };
  }
  if(pedido <= max){
    const pAceita = 0.85 - 0.55 * (pedido - oferta) / Math.max(1, max - oferta);
    if(Math.random() < pAceita) return fechar(pedido, t);
  }
  // contraproposta da empresa: meio caminho entre a oferta e o pedido, nunca acima do máximo
  const contraValor = patRound(Math.min(max * 0.97, oferta + (pedido - oferta) * 0.5));
  prop.contra = { valor: Math.max(oferta, contraValor), termos: t };
  prop.termos = t;
  prop.lowball = clamp(prop.contra.valor / Math.max(1, prop.base * patTermosMult(t)), prop.lowball, prop.margem);   // a oferta atual passa a ser a contraproposta
  return { ok: true, estado: "contra", valor: prop.contra.valor, msg: `A ${prop.empresa} contrapropõe ${fmtMoney(prop.contra.valor)} por época para estes termos.` };
}

// Procura ativa (departamento comercial): custo e prazo, resultado incerto.
function patrocinioCustoProcura(team){ return Math.round(clamp(patRef(team) * 0.012, 800, 12000)); }
function patrocinioProcurar(team, categoria){
  const p = patrocinioEnsure(team);
  if(!p) return { ok: false, reason: "Sem estrutura de patrocínios." };
  if(p.procura) return { ok: false, reason: "O departamento comercial já está a procurar um patrocinador." };
  if(!PAT_CATEGORIAS[categoria] || patSlotsLivres(team)[categoria] <= 0) return { ok: false, reason: "Não há vaga nesta categoria." };
  const custo = patrocinioCustoProcura(team);
  if((team.financeiro.saldo || 0) < custo) return { ok: false, reason: "Saldo insuficiente para pagar a procura." };
  addFinanceMovement(team, "despesa", "Patrocínio", `Procura ativa de patrocinador (${PAT_CATEGORIAS[categoria].label})`, custo, state.currentDate);
  p.procura = { categoria, custo, inicio: patIso(), fim: patIso(new Date(new Date(state.currentDate).getTime() + PAT_PROCURA_DIAS * 86400000)) };
  return { ok: true, custo, fim: p.procura.fim };
}
function patProbProcura(team){
  const rep = normalizeClubReputation(team.reputacao, team);
  return clamp(0.45 + (rep - 50) * 0.006 + (patMomento(team) - 1), 0.3, 0.9);
}

// ---------------------------------------------------------------------------------------------
// Efeitos de exposição noutros sistemas (televisão, adeptos)
// ---------------------------------------------------------------------------------------------
function patExposicaoNivel(team){
  if(!patElegivel(team) || !team.patrocinios) return 0;
  return team.patrocinios.contratos.filter(c => c.estado === "ativo").reduce((m, c) => Math.max(m, c.exposicao || 0), 0);
}
function patrocinioTvMult(team){
  const ativos = patElegivel(team) && team.patrocinios ? team.patrocinios.contratos.filter(c => c.estado === "ativo") : [];
  const tot = ativos.reduce((a, c) => a + c.valorAnual, 0);
  if(!tot) return 1;
  return 1 + PAT_TV_BONUS_POR_NIVEL * ativos.reduce((a, c) => a + c.valorAnual * (c.exposicao || 0), 0) / tot;
}
function patrocinioTvInteresse(team){ return PAT_TV_INTERESSE_POR_NIVEL * patExposicaoNivel(team); }

// ---------------------------------------------------------------------------------------------
// Pagamento mensal (chamado por processMonthlyFinances com o valor já calibrado)
// ---------------------------------------------------------------------------------------------
function patrocinioPagarMensal(team, valor, date){
  const ativos = patContratos(team);
  const tot = ativos.reduce((a, c) => a + c.valorAnual, 0);
  if(!patEhUtilizador(team) || !ativos.length || tot <= 0 || valor <= 0){
    addFinanceMovement(team, "receita", "Patrocínio", `Prestação mensal dos patrocinadores${team.financeiro.sponsorNome ? ` (${team.financeiro.sponsorNome})` : ""}`, valor, date);
    return;
  }
  let pago = 0;
  ativos.forEach((c, i) => {
    const parte = i === ativos.length - 1 ? valor - pago : Math.round(valor * c.valorAnual / tot);
    pago += parte;
    if(parte > 0) addFinanceMovement(team, "receita", "Patrocínio", `Prestação mensal — ${c.empresa} (${PAT_CATEGORIAS[c.categoria].label.toLowerCase()})`, parte, date);
  });
}

// ---------------------------------------------------------------------------------------------
// Satisfação, propostas inbound, preenchimento de vagas pela IA (mensal, todos os clubes)
// ---------------------------------------------------------------------------------------------
function patSatisfacaoAlvo(team, c){
  const a = typeof ensureAdeptos === "function" ? ensureAdeptos(team) : null;
  const humor = a ? a.humor : 50;
  const conf = team.confiancaDirecao != null ? team.confiancaDirecao : 60;
  let alvo = 30 + conf * 0.5 + (humor - 50) * 0.15;
  const tv = (typeof tvEnsure === "function") ? tvEnsure(team).jogos : 0;
  if(c.exposicao > 0) alvo += tv >= 1 ? 8 : -8;
  const inc = team.disciplina && team.disciplina.epoca === state.season ? (team.disciplina.incidentesEpoca || 0) : 0;
  alvo -= inc >= 2 ? 12 : inc === 1 ? 5 : 0;
  return clamp(alvo, 0, 100);
}
function patrocinioSatisfacaoMensal(team){
  const p = patrocinioEnsure(team); if(!p) return;
  const hoje = patIso();
  p.contratos.filter(c => c.estado === "ativo").forEach(c => {
    c.sat = clamp((c.sat != null ? c.sat : 60) + (patSatisfacaoAlvo(team, c) - (c.sat != null ? c.sat : 60)) * 0.3, 0, 100);
    if(c.sat >= 40){ c.aviso = null; return; }
    if(c.sat > PAT_SAT_BAIXA) return;
    if(!c.aviso){
      c.aviso = hoje;
      patNoticia(team, `${c.empresa} está descontente`,
        `A ${escapeHtml(c.empresa)} (${escapeHtml(PAT_CATEGORIAS[c.categoria].label.toLowerCase())}) comunica que está insatisfeita com os resultados, o ambiente com os adeptos e a exposição do clube. Se nada mudar nos próximos dois meses, o contrato pode ser rescindido.`, c.empresa, true);
    } else if((new Date(hoje) - new Date(c.aviso)) / 86400000 >= PAT_SAT_AVISO_DIAS){
      patNoticia(team, `${c.empresa} rescindiu o contrato`,
        `A ${escapeHtml(c.empresa)} rescindiu o contrato de patrocínio por incumprimento das expectativas, sem direito a indemnização. A vaga fica livre para novas propostas.`, c.empresa, true);
      patEncerrar(team, c, "rescindido pela empresa (incumprimento)");
    }
  });
}
function patGerarTermosIA(){
  const r = Math.random;
  return { duracao: 1 + Math.floor(r() * 4), modelo: r() < 0.15 ? "variavel" : "fixo", descida: r() < 0.7 ? "nenhuma" : r() < 0.67 ? "reduz" : "rescinde",
    exclusivo: r() < 0.15, exposicao: r() < 0.7 ? 0 : r() < 0.83 ? 1 : 2 };
}
function patIaPreencherVagas(team){
  const livres = patSlotsLivres(team);
  PAT_ORDEM.forEach(cat => {
    for(let n = 0; n < livres[cat]; n++){
      if(Math.random() > 0.4) continue;
      const p = team.patrocinios;
      const usadosSetor = new Set(patContratos(team).map(c => c.setor));
      const setor = patSetorLivre(team, cat, patExclusivos(team), usadosSetor, null); if(!setor) continue;
      const usados = new Set(p.contratos.map(c => c.empresa));
      const termos = patGerarTermosIA();
      const valor = patRound(patBase(team, cat) * patTermosMult(termos) * (0.95 + Math.random() * 0.05));
      patAssinar(team, { categoria: cat, empresa: patNomeEmpresa(team, setor, usados), setor, valor, termos, origem: "ia" });
    }
  });
}
function patUtilizadorMensal(team, date){
  const p = patrocinioEnsure(team); if(!p) return;
  const mes = new Date(date).getMonth();
  // Renovações: de fevereiro a julho da última época do contrato
  if(mes >= 1 && mes <= 6){
    p.contratos.filter(c => c.estado === "ativo" && c.fim <= state.season && !c.renovacaoProposta && !c.renovado).forEach(c => {
      c.renovacaoProposta = true;
      if(c.sat >= 35) patNovaProposta(team, c.categoria, "renovacao", { contratoId: c.id });
      else patNoticia(team, `${c.empresa} não vai renovar`, `A ${escapeHtml(c.empresa)} informa que não pretende renovar o contrato no fim da época, por insatisfação com o desempenho do clube.`, c.empresa, false);
    });
  }
  // Propostas novas para vagas livres (no máximo 2 pendentes)
  const pendentes = p.propostas.filter(x => x.tipo === "nova");
  if(pendentes.length < 2){
    const livres = patSlotsLivres(team);
    const rep = normalizeClubReputation(team.reputacao, team);
    const prob = clamp(0.18 + (rep - 50) * 0.004 + (patMomento(team) - 1) * 0.5, 0.05, 0.5);
    const cats = PAT_ORDEM.filter(cat => livres[cat] - pendentes.filter(x => x.categoria === cat).length > 0);
    if(cats.length && Math.random() < prob) patNovaProposta(team, cats[Math.floor(Math.random() * cats.length)], "nova", {});
  }
}
function patrocinioMensal(date){
  const d = new Date(date); const mesKey = `${d.getFullYear()}-${d.getMonth() + 1}`;
  Object.values(state.teams).forEach(team => {
    if(!patElegivel(team)) return;
    if(!patrocinioEnsure(team)) return;
    if(team.patrocinios.ultimoMes === mesKey) return;
    team.patrocinios.ultimoMes = mesKey;
    if(!team.patrocinios.contratos.length && !(team.financeiro.receitaMensalPatrocinio > 0) && !patEhUtilizador(team)) return;
    patrocinioSatisfacaoMensal(team);
    if(patExposicaoNivel(team) >= 2 && typeof ensureAdeptos === "function"){ const a = ensureAdeptos(team); a.humor = clamp(a.humor - PAT_EXPOSICAO_HUMOR, 0, 100); }
    if(patEhUtilizador(team)) patUtilizadorMensal(team, date);
    else patIaPreencherVagas(team);
  });
}

// Diário: propostas caducadas e procura ativa do utilizador.
function patrocinioDiario(){
  const team = state.teams[state.userTeamId];
  if(!patElegivel(team) || !team.patrocinios) return;
  const p = team.patrocinios, hoje = patIso();
  p.propostas = p.propostas.filter(prop => {
    if(prop.expira >= hoje) return true;
    patNoticia(team, `Proposta de ${prop.empresa} caducou`, `A proposta da ${escapeHtml(prop.empresa)} caducou sem resposta e foi retirada.`, prop.empresa, false);
    return false;
  });
  if(p.procura && p.procura.fim <= hoje){
    const proc = p.procura; p.procura = null;
    const livre = patSlotsLivres(team)[proc.categoria] > 0;
    if(livre && Math.random() < patProbProcura(team)){
      const prop = patNovaProposta(team, proc.categoria, "nova", { ativa: true });
      if(prop) prop.ativa = true;
      else patNoticia(team, "Procura de patrocinador sem resultados", "O departamento comercial não encontrou empresas disponíveis neste momento.", "Departamento comercial", false);
    } else {
      patNoticia(team, "Procura de patrocinador sem resultados", `O departamento comercial não conseguiu interessar nenhuma empresa para a categoria ${escapeHtml(PAT_CATEGORIAS[proc.categoria].label.toLowerCase())}. Pode tentar de novo mais tarde.`, "Departamento comercial", true);
    }
  }
}

// ---------------------------------------------------------------------------------------------
// Fim de época (depois de recordDirectionEvaluation): bónus, descida, expiração e renovações
// ---------------------------------------------------------------------------------------------
function patrocinioFimDeEpoca(){
  Object.values(state.teams).forEach(team => {
    if(!patElegivel(team) || !team.patrocinios) return;
    const p = team.patrocinios;
    const av = team.avaliacaoDirecao && team.avaliacaoDirecao[0];
    const objGoal = av && (av.goals || []).find(g => /^Objetivo do patrocinador/.test(g.label));
    const objOk = av && av.sponsorOk!==undefined ? !!av.sponsorOk : !!(objGoal && objGoal.ok), champion = !!(av && av.champion), relegated = !!(av && av.relegated);
    const europa = !!(state.europa && state.europa.edicao && state.europa.edicao.participantes && state.europa.edicao.participantes[team.id]);
    const user = patEhUtilizador(team);
    p.contratos.filter(c => c.estado === "ativo").forEach(c => {
      // Bónus (só contratos variáveis)
      if(c.modelo === "variavel"){
        let pct = (objOk ? PAT_BONUS_OBJETIVO : 0) + (champion ? PAT_BONUS_TITULO : 0) + (europa ? PAT_BONUS_EUROPA : 0);
        if(pct > 0){
          const bonus = Math.round(c.valorAnual * pct);
          addFinanceMovement(team, "receita", "Patrocínio", `Bónus de objetivos — ${c.empresa}`, bonus, state.currentDate);
          patNoticia(team, `Bónus de ${c.empresa}`, `A ${escapeHtml(c.empresa)} pagou um bónus de ${fmtMoney(bonus)} pelos objetivos alcançados esta época.`, c.empresa, false);
        }
      }
      // Cláusula de descida
      if(relegated && c.descida === "rescinde"){
        patNoticia(team, `${c.empresa} rescinde por causa da descida`, `Com a descida de divisão, a ${escapeHtml(c.empresa)} acionou a cláusula e rescindiu o contrato.`, c.empresa, true);
        patEncerrar(team, c, "rescindido (cláusula de descida)"); return;
      }
      if(relegated && c.descida === "reduz"){
        c.valorAnual = Math.round(c.valorAnual * PAT_DESCIDA_REDUZ);
        patNoticia(team, `${c.empresa} reduz o patrocínio`, `Com a descida de divisão, a ${escapeHtml(c.empresa)} acionou a cláusula e o valor anual desce para ${fmtMoney(c.valorAnual)}.`, c.empresa, false);
      }
      // Expiração / renovação
      if(c.fim <= state.season){
        if(c.proxima){
          c.valorAnual = c.proxima.valorAnual; c.modelo = c.proxima.termos.modelo; c.descida = c.proxima.termos.descida;
          c.exclusivo = !!c.proxima.termos.exclusivo; c.exposicao = c.proxima.termos.exposicao || 0;
          c.inicio = state.season + 1; c.fim = c.inicio + c.proxima.termos.duracao - 1;
          c.proxima = null; c.renovado = false; c.renovacaoProposta = false; c.origem = "renovacao"; c.sat = Math.max(c.sat, 65);
        } else if(!user && Math.random() < 0.9){
          const termos = patGerarTermosIA();
          c.valorAnual = patRound(patBase(team, c.categoria) * patTermosMult(termos) * (0.95 + Math.random() * 0.05));
          c.modelo = termos.modelo; c.descida = termos.descida; c.exclusivo = termos.exclusivo; c.exposicao = termos.exposicao;
          c.inicio = state.season + 1; c.fim = c.inicio + termos.duracao - 1; c.renovacaoProposta = false; c.renovado = false; c.origem = "ia";
        } else {
          patNoticia(team, `Contrato com ${c.empresa} terminou`, `O contrato com a ${escapeHtml(c.empresa)} chegou ao fim e não foi renovado. A vaga fica livre para novas propostas.`, c.empresa, false);
          patEncerrar(team, c, "terminou");
        }
      }
    });
    p.propostas = [];   // propostas pendentes caducam na mudança de época
    patrocinioSync(team);
  });
}

// ---------------------------------------------------------------------------------------------
// Interface: secção "Patrocínios" no painel da Direção
// ---------------------------------------------------------------------------------------------
function patSatTexto(s){ return s >= 70 ? "Muito satisfeito" : s >= 50 ? "Satisfeito" : s >= 35 ? "Reticente" : "Descontente"; }
function patrocinioPanelHtml(team){
  const p = patrocinioEnsure(team); if(!p) return "";
  const ativos = p.contratos.filter(c => c.estado === "ativo");
  const total = ativos.reduce((a, c) => a + c.valorAnual, 0);
  const linhas = PAT_ORDEM.map(cat => ativos.filter(c => c.categoria === cat)).flat().map(c => {
    const termos = patTermosTexto(c);
    const renov = c.proxima ? `<div class="helptext">Renovação acordada: ${fmtMoney(c.proxima.valorAnual)} por época, ${c.proxima.termos.duracao} épocas.</div>` : "";
    return `<tr><td>${escapeHtml(PAT_CATEGORIAS[c.categoria].label)}</td><td><b>${escapeHtml(c.empresa)}</b><div class="helptext">${escapeHtml(PAT_SETOR_ROTULO[c.setor] || "")}${termos ? ` · ${escapeHtml(termos)}` : ""}</div>${renov}</td>
      <td class="num">${fmtMoney(c.valorAnual)}</td><td>${seasonLabel(c.fim)}</td><td>${patSatTexto(c.sat != null ? c.sat : 60)}${c.aviso ? ' <span class="money-neg">⚠ aviso</span>' : ""}</td>
      <td><button class="btn btn-ghost pat-rescindir" data-contrato="${escapeHtml(c.id)}">Rescindir</button></td></tr>`;
  }).join("");
  const livres = patSlotsLivres(team);
  const procura = p.procura ? `<p class="helptext">Procura ativa em curso (${escapeHtml(PAT_CATEGORIAS[p.procura.categoria].label)}): resultado a ${patFmt(p.procura.fim)}.</p>` : "";
  const botoesProcura = !p.procura ? PAT_ORDEM.filter(cat => livres[cat] > 0).map(cat => `<button class="btn btn-ghost pat-procurar" data-cat="${cat}">Procurar: ${escapeHtml(PAT_CATEGORIAS[cat].label)} (${fmtMoney(patrocinioCustoProcura(team))})</button>`).join(" ") : "";
  const props = p.propostas.map(x => `<tr><td>${x.tipo === "renovacao" ? "Renovação" : "Proposta"}</td><td><b>${escapeHtml(x.empresa)}</b><div class="helptext">${escapeHtml(PAT_CATEGORIAS[x.categoria].label)} · ${x.termos.duracao} épocas${x.contra ? " · contraproposta da empresa" : ""}</div></td><td class="num">${fmtMoney(patOferta(x, x.termos))}</td><td>até ${patFmt(x.expira)}</td><td><button class="btn btn-primary pat-negociar" data-prop="${escapeHtml(x.id)}">Negociar</button></td></tr>`).join("");
  return `<div class="eyebrow" style="margin:16px 0 8px;">Patrocínios</div>
    <p class="helptext" style="margin-bottom:8px;">Receita anual contratada: <b>${fmtMoney(total)}</b>. Cada patrocinador tem valor, duração e cláusulas próprias; as empresas contactam o clube, e o departamento comercial pode procurar novas. Contratos com valor variável pagam bónus de objetivos no fim da época. Valores e margens de negociação são estimativas do jogo.</p>
    <table class="stat-list"><thead><tr><th>Categoria</th><th>Patrocinador</th><th class="num">Valor/época</th><th>Termina</th><th>Satisfação</th><th></th></tr></thead><tbody>${linhas || '<tr><td colspan="6" class="helptext">Sem patrocinadores.</td></tr>'}</tbody></table>
    ${props ? `<div class="eyebrow" style="margin:12px 0 6px;">Propostas recebidas</div><table class="stat-list"><thead><tr><th>Tipo</th><th>Empresa</th><th class="num">Oferta/época</th><th>Prazo</th><th></th></tr></thead><tbody>${props}</tbody></table>` : ""}
    ${procura}<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">${botoesProcura}</div>`;
}

let patPropostaAberta = null;
function patSelect(id, opts, valor){ return `<select id="${id}">${opts.map(([v, l]) => `<option value="${v}" ${String(v) === String(valor) ? "selected" : ""}>${l}</option>`).join("")}</select>`; }
function patAbrirNegociacao(propId){
  const team = myTeam(); const p = team && team.patrocinios; const prop = p && p.propostas.find(x => x.id === propId);
  if(!prop) return;
  patPropostaAberta = propId;
  const t = prop.termos, oferta = patOferta(prop, t);
  const html = `<p class="helptext">${escapeHtml(prop.empresa)} · ${escapeHtml(PAT_CATEGORIAS[prop.categoria].label)}${prop.tipo === "renovacao" ? " · renovação (começa na próxima época)" : ""}. Rondas de negociação usadas: ${prop.rondas}/${PAT_RONDAS_MAX}.${prop.contra ? " A empresa já fez uma contraproposta." : ""}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
      <label style="font-size:12px;">Duração${patSelect("patDur", [1, 2, 3, 4, 5].map(n => [n, `${n} ${n > 1 ? "épocas" : "época"}`]), t.duracao)}</label>
      <label style="font-size:12px;">Valor${patSelect("patMod", [["fixo", "Fixo"], ["variavel", "Variável (bónus)"]], t.modelo)}</label>
      <label style="font-size:12px;">Se o clube descer${patSelect("patDesc", [["nenhuma", "Sem cláusula"], ["reduz", "Valor desce 40%"], ["rescinde", "Rescinde"]], t.descida)}</label>
      <label style="font-size:12px;">Exposição${patSelect("patExp", PAT_EXPOSICAO_LABEL.map((l, i) => [i, l]), t.exposicao)}</label>
      <label style="font-size:12px;"><input type="checkbox" id="patExcl" ${t.exclusivo ? "checked" : ""}> Exclusividade no setor</label>
      <label style="font-size:12px;">Valor pedido por época (€)<input type="number" id="patValor" min="1000" step="100" value="${oferta}"></label>
    </div>
    <p class="helptext" id="patOfertaInfo" style="margin-top:8px;">Oferta da empresa para estes termos: <b>${fmtMoney(oferta)}</b> por época. Pedir mais do que a oferta pode levar a uma contraproposta ou à desistência. Exposição máxima aumenta o bónus de televisão mas cansa os adeptos.</p>
    <div style="margin-top:12px;display:flex;gap:8px;"><button class="btn btn-primary" id="patEnviar">Enviar</button><button class="btn btn-ghost" id="patRecusar">Recusar proposta</button></div>`;
  empJanelaModal(`Negociar — ${prop.empresa}`, html);
}
function patLerTermos(){
  const m = balnearioModalEl();
  return { duracao: parseInt(m.querySelector("#patDur").value, 10), modelo: m.querySelector("#patMod").value, descida: m.querySelector("#patDesc").value,
    exposicao: parseInt(m.querySelector("#patExp").value, 10), exclusivo: m.querySelector("#patExcl").checked };
}
document.addEventListener("change", (e) => {
  const t = e.target; if(!t || !t.closest || !t.closest("#balnearioModal") || !patPropostaAberta) return;
  if(!["patDur", "patMod", "patDesc", "patExp", "patExcl"].includes(t.id)) return;
  const team = myTeam(); const prop = team && team.patrocinios && team.patrocinios.propostas.find(x => x.id === patPropostaAberta); if(!prop) return;
  const oferta = patOferta(prop, patLerTermos());
  const m = balnearioModalEl();
  m.querySelector("#patValor").value = oferta;
  m.querySelector("#patOfertaInfo").innerHTML = `Oferta da empresa para estes termos: <b>${fmtMoney(oferta)}</b> por época.`;
});
document.addEventListener("click", (e) => {
  const t = e.target; if(!t || !t.closest) return;
  const team = myTeam();
  const rs = t.closest(".pat-rescindir");
  if(rs && team){
    const c = (team.patrocinios && team.patrocinios.contratos.find(x => x.id === rs.getAttribute("data-contrato")));
    if(!c) return;
    const epocas = clamp(c.fim - state.season + 1, 1, 3), multa = Math.round(c.valorAnual * PAT_RESCISAO_FRAC * epocas);
    empJanelaModal(`Rescindir — ${c.empresa}`, `<p>Rescindir o contrato com a ${escapeHtml(c.empresa)} custa uma indemnização de <b>${fmtMoney(multa)}</b> e o clube perde ${fmtMoney(c.valorAnual)} por época até arranjar substituto.</p><button class="btn btn-primary" id="patRescindirOk" data-contrato="${escapeHtml(c.id)}">Confirmar rescisão</button>`);
    return;
  }
  const ok = t.closest("#patRescindirOk");
  if(ok && team){
    const r = patrocinioRescindir(team, ok.getAttribute("data-contrato"));
    balnearioModalEl().classList.add("hidden");
    showTransientNotice(r.ok ? `Contrato rescindido (${fmtMoney(r.multa)} de indemnização).` : r.reason);
    if(typeof renderDirectionPanel === "function") renderDirectionPanel();
    return;
  }
  const pr = t.closest(".pat-procurar");
  if(pr && team){
    const r = patrocinioProcurar(team, pr.getAttribute("data-cat"));
    showTransientNotice(r.ok ? `O departamento comercial começou a procurar (${fmtMoney(r.custo)}). Resultado a ${patFmt(r.fim)}.` : r.reason);
    if(typeof renderDirectionPanel === "function") renderDirectionPanel();
    return;
  }
  const ng = t.closest(".pat-negociar");
  if(ng){ patAbrirNegociacao(ng.getAttribute("data-prop")); return; }
  if(t.closest("#patEnviar") && team && patPropostaAberta){
    const vp = parseInt(balnearioModalEl().querySelector("#patValor").value, 10);
    const r = patrocinioResponder(team, patPropostaAberta, "contrapropor", patLerTermos(), vp);
    if(r.estado === "contra"){ patAbrirNegociacao(patPropostaAberta); showTransientNotice(r.msg); }
    else { balnearioModalEl().classList.add("hidden"); patPropostaAberta = null; showTransientNotice(r.msg || r.reason); }
    if(typeof renderDirectionPanel === "function") renderDirectionPanel();
    return;
  }
  if(t.closest("#patRecusar") && team && patPropostaAberta){
    const r = patrocinioResponder(team, patPropostaAberta, "recusar");
    balnearioModalEl().classList.add("hidden"); patPropostaAberta = null;
    showTransientNotice(r.msg || r.reason);
    if(typeof renderDirectionPanel === "function") renderDirectionPanel();
  }
});
