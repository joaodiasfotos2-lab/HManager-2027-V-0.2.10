// =================================================================
// Formação: pontos do objetivo da direção + folha de fim de época da B / Sub-19 (2026-10-14)
// =================================================================
// 1) Objetivo de formação (08y-presidentes.js) passa a contar em PONTOS: cada sub-23 da equipa A
//    com o mínimo de jogos vale 1; cada formado no clube (clubeFormadorId, gravado na promoção da
//    academia) com idade <= 23 e FB_MIN_JOGOS_B jogos pela equipa B vale ½. Como a B é o Sub-19
//    (08b-academia-juvenis.js, academyHasB), é assim que a direção reconhece o trabalho da formação.
// 2) Folha de fim de época (só o clube do utilizador): e-mail do "Departamento de Formação" e
//    histórico por época no separador Academia da ficha do clube. fbSnapshot() corre ANTES de
//    closeCompletedSeasonPlayerStats (que reinicia player.season) e fbGerar() depois da passagem
//    anual da academia (promovidos e dispensados ficam em academy.exitLog).

const FB_MIN_JOGOS_B = 10;

function fbJogos(p){ return (p && seasonStatsForDecision(p).jogos) || 0; }
function fbGolos(p){ return (p && p.season && p.season.golos) || 0; }
function fbFmt(n){ return String(Math.round(n * 10) / 10).replace(".", ","); }

// Pontos de formação de um clube (equipa A + equipa B), ver cabeçalho.
function fbPontos(dono, minJogos){
  const B = dono.equipaBId && state.teams[dono.equipaBId];
  const subA = (dono.players || []).filter(p => p.age <= 23 && fbJogos(p) >= minJogos);
  const ids = new Set(subA.map(p => p.id));
  const formB = B ? (B.players || []).filter(p => p.age <= 23 && p.clubeFormadorId === dono.id && !ids.has(p.id) && fbJogos(p) >= FB_MIN_JOGOS_B) : [];
  return { pontos: subA.length + 0.5 * formB.length, subA, formB };
}

// --- Folha de fim de época -------------------------------------------------------------------
function fbSnapshot(){
  state.fbSnap = null;
  const a = typeof myTeam === "function" ? myTeam() : null;
  if(!a || !a.academy || a.equipaPrincipalId) return;
  const B = a.equipaBId && state.teams[a.equipaBId];
  const snap = { season: state.season, label: seasonLabel(state.season), clubId: a.id, temB: !!B, b: null, jovens: [], pontos: null };
  if(B){
    try {
      const comp = competitionOfTeam(B);
      let pos = null, total = null;
      if(comp && comp.teamIds.length >= 3){
        const tab = standingsForCompetition(comp.id), idx = tab.findIndex(t => t.id === B.id);
        if(idx >= 0){ pos = idx + 1; total = tab.length; }
      }
      const st = B.stats || {};
      snap.b = { compId: comp ? comp.id : null, pos, total, J: st.J || 0, V: st.V || 0, E: st.E || 0, D: st.D || 0, GM: st.GM || 0, GS: st.GS || 0, Pts: st.Pts || 0 };
    } catch(e){ snap.b = null; }
    snap.jovens = (B.players || []).filter(p => p.age <= 23 && fbJogos(p) > 0)
      .sort((x, y) => fbJogos(y) - fbJogos(x) || overall(y) - overall(x)).slice(0, 6)
      .map(p => ({ id: p.id, nome: p.name, age: p.age, pos: p.pos, jogos: fbJogos(p), golos: fbGolos(p), ovr: overall(p), pot: visiblePotentialLabel(p, B), formado: p.clubeFormadorId === a.id }));
  }
  const obj = typeof presObjetivosAtuais === "function" ? presObjetivosAtuais(a) : null;
  const item = obj && obj.itens ? obj.itens.find(o => o.tipo === "formacao") : null;
  const minJ = (item && item.minJogos) || (typeof PRES_FORMACAO_MIN_JOGOS !== "undefined" ? PRES_FORMACAO_MIN_JOGOS : 5);
  const r = fbPontos(a, minJ);
  snap.pontos = { pontos: r.pontos, subA: r.subA.length, formB: r.formB.length, alvo: item ? item.jogadores : null, principal: item ? !!item.principal : false };
  state.fbSnap = snap;
}

function fbConvocadosSub19(clube){
  const ids = new Set([clube.id, clube.equipaBId].filter(Boolean));
  const out = [];
  const conv = state.selecoesUltimaConvocatoria || {};
  Object.keys(conv).forEach(code => {
    if(code.indexOf("s19-") !== 0) return;
    const c = conv[code];
    (c.jogadores || []).forEach(j => { if(!j.filler && ids.has(j.teamId)) out.push({ ...j, code, edicao: c.seasonLabel, prova: c.prova }); });
  });
  return out;
}

function fbOrd(n){ return `${n}.º`; }

function fbGerar(){
  const snap = state.fbSnap;
  state.fbSnap = null;
  const a = typeof myTeam === "function" ? myTeam() : null;
  if(!snap || !a || a.id !== snap.clubId || !a.academy) return;
  const B = snap.temB && state.teams[a.equipaBId];
  const exit = (a.academy.exitLog && a.academy.exitLog.season === state.season) ? a.academy.exitLog : { promovidos: [], dispensados: [] };
  const nomeEquipa = id => (state.teams[id] ? state.teams[id].name : "—");
  const nomeLink = (id, p) => id && state.teams[id] && state.teams[id].players.some(x => x.id === p.id) ? playerLinkHtml(id, state.teams[id].players.find(x => x.id === p.id)) : escapeHtml(p.nome);
  const secoes = [];
  if(snap.b){
    const b = snap.b;
    secoes.push({ icone: "🏒", titulo: "Equipa B (o nosso Sub-19)", linhas: [
      ["Classificação", b.pos ? `<b>${fbOrd(b.pos)}</b> de ${b.total} · ${b.Pts} pontos em ${b.J} jogos` : "indisponível"],
      ["Resultados", `${b.V}V ${b.E}E ${b.D}D · golos ${b.GM}-${b.GS}`],
    ] });
    secoes.push({ icone: "⏱️", titulo: "Jovens que mais jogaram na B", linhas: snap.jovens.length
      ? snap.jovens.map(j => [nomeLink(B.id, j), `${j.age} anos · ${j.jogos} jogos · ${j.golos} golos · OVR ${j.ovr} · perspetiva ${String(j.pot).toLowerCase()}${j.formado ? " · formado no clube" : ""}`])
      : [["", "nenhum jovem (sub-23) jogou pela equipa B"]] });
  }
  secoes.push({ icone: "⬆️", titulo: "Promovidos da academia", linhas: exit.promovidos.length
    ? exit.promovidos.map(p => [nomeLink(p.destinoId, p), `${p.age} anos · OVR ${p.ovr} · perspetiva ${String(p.pot).toLowerCase()} · para ${escapeHtml(nomeEquipa(p.destinoId))}`])
    : [["", "nenhum jovem subiu da academia nesta época"]] });
  if(exit.dispensados.length){
    secoes.push({ icone: "⬇️", titulo: "Saídas sem promoção", linhas: [["Dispensados", `${exit.dispensados.length}${exit.dispensados.length ? " · " + exit.dispensados.slice(0, 6).map(p => `${escapeHtml(p.nome)} (OVR ${p.ovr}, perspetiva ${String(p.pot).toLowerCase()})`).join(", ") : ""}`]] });
  }
  const conv = fbConvocadosSub19(a);
  secoes.push({ icone: "🌍", titulo: "Selecções Sub-19", linhas: conv.length
    ? conv.map(j => [escapeHtml(j.nome), `${escapeHtml(j.pos)} · ${selecaoNationOf ? escapeHtml((SELECAO_NATIONS[selecaoBaseCode(j.code)] || {}).nome || j.code) : j.code} · edição ${escapeHtml(j.edicao || "")}`])
    : [["", "nenhum jogador do clube convocado para a próxima edição Sub-19"]] });
  const pt = snap.pontos;
  if(pt){
    const alvo = pt.alvo != null ? ` de ${pt.alvo}` : "";
    secoes.push({ icone: "🎯", titulo: "Objetivo de formação da direção", linhas: [
      ["Pontos", `<b>${fbFmt(pt.pontos)}</b>${alvo} (sub-23 na A: ${pt.subA} · formados na B: ${pt.formB} × ½)`],
      ["Estado", pt.alvo == null ? "a direção não fixou este objetivo nesta época" : (pt.pontos >= pt.alvo ? "cumprido" : "falhado") + (pt.principal ? " (objetivo principal)" : "")],
    ] });
  }
  const chips = [];
  if(snap.b && snap.b.pos) chips.push(repChip(`B: ${fbOrd(snap.b.pos)} de ${snap.b.total}`));
  chips.push(repChip(`${exit.promovidos.length} promovido${exit.promovidos.length === 1 ? "" : "s"}`, exit.promovidos.length ? "ok" : ""));
  if(exit.dispensados.length) chips.push(repChip(`${exit.dispensados.length} dispensado${exit.dispensados.length === 1 ? "" : "s"}`, "aviso"));
  if(conv.length) chips.push(repChip(`${conv.length} no Sub-19`, "ok"));
  const resumo = `${snap.b ? `A equipa B terminou ${snap.b.pos ? fbOrd(snap.b.pos) : "a época"} e deu ${snap.jovens.length} jovens com jogos. ` : ""}${exit.promovidos.length} subiram da academia, ${exit.dispensados.length} saíram.${pt && pt.alvo != null ? ` Objetivo de formação: ${pt.pontos >= pt.alvo ? "cumprido" : "falhado"}.` : ""}`;
  const html = repDoc({
    teamId: a.id, org: "Departamento de Formação", titulo: "Folha de formação — fim de época",
    sub: `Época ${snap.label}`, chips, resumo, secoes, rodape: "Folha de fim de época · equipa B e academia",
  });
  if(!Array.isArray(a.academy.folhas)) a.academy.folhas = [];
  a.academy.folhas = a.academy.folhas.filter(f => f.label !== snap.label);
  a.academy.folhas.unshift({ label: snap.label, season: snap.season, html });
  if(a.academy.folhas.length > 10) a.academy.folhas.length = 10;
  pushNews(state.currentDate, html, "juventude", `Folha de formação ${snap.label}`);
}

// Painel no separador Academia da ficha do clube (só o clube do utilizador tem folhas).
function fbFolhasHtml(team){
  const f = team && team.academy && team.academy.folhas;
  if(!Array.isArray(f) || !f.length) return "";
  return `<div class="pm-retro-section-lbl">Folhas de formação</div>` + f.map((x, i) =>
    `<details class="rep-det"${i === 0 ? " open" : ""}><summary>Época ${escapeHtml(x.label)}</summary><div>${x.html}</div></details>`).join("");
}
